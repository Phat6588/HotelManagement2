package entity;

import java.time.LocalDate;

public record KhachHang_SuDung_DichVuEntity(
    int maKHSDDV,
    String maKH,
    String maDV,
    LocalDate ngaySuDung,
    int soLuong,
    String ghiChu,
    boolean daThanhToan,
    String maHD
) {}
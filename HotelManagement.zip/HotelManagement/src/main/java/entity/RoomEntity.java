package entity;

public record RoomEntity(String maPhong, String tenPhong, String tinhTrang, double giaPhong) {}
package entity;

public record ChiTietHoaDon_DichVuEntity(
    String maHD,
    String maDV,
    int soLuong,
    double donGiaTaiThoiDiemSuDung,
    double thanhTien
) {}

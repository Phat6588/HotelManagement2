package entity;

import java.time.LocalDate;

public record HoaDonEntity(
    String maHD,
    String maKH,
    String maNV,
    LocalDate ngayLapHD,
    double tongTienPhong,
    double tongTienDichVu,
    double tongCong,
    String ghiChu
) {}
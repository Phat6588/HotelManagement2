package entity;

import java.time.LocalDate;

public record HoaDonEntity(
    String maHD,
    String maKH,
    String maNV,
    String maPhong,
    LocalDate ngayLapHD,
    double tongTienPhong,
    double tongTienDichVu,
    double tongCong,
    String ghiChu
) {}
package entity;

import java.sql.Date;
import java.time.LocalDate;

public record KhachHangEntity(
    String maKH,     
    String tenKH,      
    String cmnd,       
    String sdt,       
    String diaChi,     
    LocalDate ngayNhan,
    LocalDate ngayTra  
) {}

package entity;

public record NhanVienEntity(String maNV, String tenNV, String chucVu) {}
package entity;

import java.sql.Date;

public record DonHangEntity(
        String maDH,
        String maKH,
        Date ngayLapDH) {

}

package databaseservice;

import entity.RoomEntity;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author dinhthai62001
 */
public class RoomSQLServerService implements IRoomDatabaseService {
    private static final String ROOM_ID = "MaPhong";
    private static final String ROOM_NAME = "TenPhong";
    private static final String STATUS = "TinhTrang";
    private static final String PRICE = "GiaPhong";

    private static RoomSQLServerService instance;

    public static RoomSQLServerService getInstance() {
        if (instance == null) {
            instance = new RoomSQLServerService();
        }
        return instance;
    }

    private RoomSQLServerService() {}

    @Override
    public List<RoomEntity> getAllRooms() {
        List<RoomEntity> list = new ArrayList<>();
        String sql = "SELECT * FROM Phong";
        try (SQLServerProvider provider = new SQLServerProvider()) {
            ResultSet rs = provider.executeQuery(sql);
            while (rs.next()) {
                list.add(new RoomEntity(
                        rs.getString(ROOM_ID),
                        rs.getString(ROOM_NAME),
                        rs.getString(STATUS),
                        rs.getDouble(PRICE)
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(RoomSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    @Override
    public int addRoom(RoomEntity entity) {
        String sql = String.format("""
                INSERT INTO Phong (%s, %s, %s, %s)
                VALUES ('%s', N'%s', N'%s', %.2f)
                """,
                ROOM_ID, ROOM_NAME, STATUS, PRICE,
                entity.maPhong(), entity.tenPhong(), entity.tinhTrang(), entity.giaPhong()
        );
        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(RoomSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
    @Override
public int updateRoom(RoomEntity room) {
    String sql = String.format("""
        UPDATE Phong 
        SET %s = N'%s', %s = N'%s', %s = %.2f 
        WHERE %s = '%s'
        """,
        ROOM_NAME, room.tenPhong(),
        STATUS, room.tinhTrang(),
        PRICE, room.giaPhong(),
        ROOM_ID, room.maPhong()
    );

    try (SQLServerProvider provider = new SQLServerProvider()) {
        return provider.executeUpdate(sql);
    } catch (SQLException ex) {
        Logger.getLogger(RoomSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
    }
    return 0;
}
@Override
public int deleteRoom(String maPhong) {
    String sql = String.format("DELETE FROM Phong WHERE MaPhong = '%s'", maPhong);
    try (SQLServerProvider provider = new SQLServerProvider()) {
        return provider.executeUpdate(sql);
    } catch (SQLException ex) {
        Logger.getLogger(RoomSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
    }
    return 0;
}
}
package databaseservice;

import entity.ChiTietHoaDon_DichVuEntity;
import entity.HoaDonEntity;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class HoaDonSQLServerService implements IHoaDonDatabaseService {

    private static HoaDonSQLServerService instance;

    public static HoaDonSQLServerService getInstance() {
        if (instance == null) {
            instance = new HoaDonSQLServerService();
        }
        return instance;
    }

    private HoaDonSQLServerService() {}

    @Override
    public List<HoaDonEntity> getAllHoaDon() {
        List<HoaDonEntity> list = new ArrayList<>();
        String sql = "SELECT MaHD, MaKH, MaNV, NgayLapHD, TongTienPhong, TongTienDichVu, TongCong, GhiChu FROM HoaDon ORDER BY NgayLapHD DESC";
        try (SQLServerProvider provider = new SQLServerProvider()) {
            ResultSet rs = provider.executeQuery(sql);
            while (rs.next()) {
                list.add(new HoaDonEntity(
                        rs.getString("MaHD"),
                        rs.getString("MaKH"),
                        rs.getString("MaNV"),
                        rs.getDate("NgayLapHD").toLocalDate(),
                        rs.getDouble("TongTienPhong"),
                        rs.getDouble("TongTienDichVu"),
                        rs.getDouble("TongCong"),
                        rs.getString("GhiChu")
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(HoaDonSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    @Override
    public HoaDonEntity getHoaDonById(String maHD) {
        String sql = String.format("SELECT MaHD, MaKH, MaNV, NgayLapHD, TongTienPhong, TongTienDichVu, TongCong, GhiChu FROM HoaDon WHERE MaHD = '%s'", maHD);
        try (SQLServerProvider provider = new SQLServerProvider()) {
            ResultSet rs = provider.executeQuery(sql);
            if (rs.next()) {
                return new HoaDonEntity(
                        rs.getString("MaHD"),
                        rs.getString("MaKH"),
                        rs.getString("MaNV"),
                        rs.getDate("NgayLapHD").toLocalDate(),
                        rs.getDouble("TongTienPhong"),
                        rs.getDouble("TongTienDichVu"),
                        rs.getDouble("TongCong"),
                        rs.getString("GhiChu")
                );
            }
        } catch (SQLException ex) {
            Logger.getLogger(HoaDonSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public int addHoaDon(HoaDonEntity entity) {
        String sql = String.format("INSERT INTO HoaDon (MaHD, MaKH, MaNV, NgayLapHD, TongTienPhong, TongTienDichVu, TongCong, GhiChu) " +
                        "VALUES ('%s', '%s', '%s', '%s', %.2f, %.2f, %.2f, N'%s')",
                entity.maHD(), entity.maKH(), entity.maNV(), entity.ngayLapHD().toString(),
                entity.tongTienPhong(), entity.tongTienDichVu(), entity.tongCong(),
                entity.ghiChu() == null ? "" : entity.ghiChu());
        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(HoaDonSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public int addChiTietHoaDon_DichVu(ChiTietHoaDon_DichVuEntity entity) {
        String sql = String.format("INSERT INTO ChiTietHoaDon_DichVu (MaHD, MaDV, SoLuong, DonGiaTaiThoiDiemSuDung, ThanhTien) " +
                        "VALUES ('%s', '%s', %d, %.2f, %.2f)",
                entity.maHD(), entity.maDV(), entity.soLuong(),
                entity.donGiaTaiThoiDiemSuDung(), entity.thanhTien());
        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(HoaDonSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
    @Override
    public List<ChiTietHoaDon_DichVuEntity> getAllChiTietHoaDonByMaHD(String maHD) {
        List<ChiTietHoaDon_DichVuEntity> list = new ArrayList<>();
        String sql = String.format("SELECT MaHD, MaDV, SoLuong, DonGiaTaiThoiDiemSuDung, ThanhTien FROM ChiTietHoaDon_DichVu WHERE MaHD = '%s'", maHD);
        try (SQLServerProvider provider = new SQLServerProvider()) {
            ResultSet rs = provider.executeQuery(sql);
            while (rs.next()) {
                list.add(new ChiTietHoaDon_DichVuEntity(
                        rs.getString("MaHD"),
                        rs.getString("MaDV"),
                        rs.getInt("SoLuong"),
                        rs.getDouble("DonGiaTaiThoiDiemSuDung"),
                        rs.getDouble("ThanhTien")
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(HoaDonSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
}
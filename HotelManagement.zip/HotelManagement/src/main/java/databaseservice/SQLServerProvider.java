package databaseservice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * SQLServerProvider
 *
 * @author hasu
 */
public class SQLServerProvider implements AutoCloseable {

    Connection connection;

    public static void dangKyDriver() throws ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
    }

    public SQLServerProvider() throws SQLException {
        this.connection = getConnection();
    }

    public void close() throws SQLException {
        if (!this.connection.isClosed()) {
            this.connection.close();
        }
    }

    public ResultSet executeQuery(String sql) throws SQLException {
        Statement statement = this.connection.createStatement();
        return statement.executeQuery(sql);
    }

    public int executeUpdate(String sql) throws SQLException {
        Statement statement = this.connection.createStatement();
        return statement.executeUpdate(sql);
    }

    private Connection getConnection() throws SQLException {
        String serverIP = "localhost";
       String databaseName = "HotelManagement";
        String user = "root";
        String pass = "admin6588";
        return getConnection(serverIP, databaseName, user, pass);
    }

   private Connection getConnection(String serverIP, String databaseName, String user, String pass) throws SQLException {
    String url = "jdbc:mysql://" + serverIP + ":3306/" + databaseName + "?useSSL=false&serverTimezone=UTC";
    return DriverManager.getConnection(url, user, pass);
   }
}

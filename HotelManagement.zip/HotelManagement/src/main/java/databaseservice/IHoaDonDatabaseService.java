package databaseservice;

import entity.ChiTietHoaDon_DichVuEntity;
import entity.HoaDonEntity;
import entity.KhachHang_SuDung_DichVuEntity;
import java.util.List;

public interface IHoaDonDatabaseService {
    List<HoaDonEntity> getAllHoaDon();
    HoaDonEntity getHoaDonById(String maHD);
    int addHoaDon(HoaDonEntity hoaDonEntity);
    int addChiTietHoaDon_DichVu(ChiTietHoaDon_DichVuEntity chiTietEntity);

    List<ChiTietHoaDon_DichVuEntity> getAllChiTietHoaDonByMaHD(String maHD);
}
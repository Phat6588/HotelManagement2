package databaseservice;

import entity.KhachHangEntity;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class KhachHangSQLServerService implements IKhachHangDatabaseService {
    private static final String MA_KH = "MaKH";
    private static final String TEN_KH = "TenKH";
    private static final String CMND = "CMND";
    private static final String SDT = "SDT";
    private static final String DIA_CHI = "DiaChi";
    private static final String NGAY_NHAN = "NgayNhan";
    private static final String NGAY_TRA = "NgayTra";

    private static KhachHangSQLServerService instance;

    public static KhachHangSQLServerService getInstance() {
        if (instance == null) {
            instance = new KhachHangSQLServerService();
        }
        return instance;
    }

    private KhachHangSQLServerService() {}

    @Override
    public List<KhachHangEntity> getAllKhachHang() {
        List<KhachHangEntity> list = new ArrayList<>();
        // Cập nhật câu SQL SELECT
        String sql = "SELECT MaKH, TenKH, CMND, SDT, DiaChi, NgayNhan, NgayTra FROM KhachHang";
        try (SQLServerProvider provider = new SQLServerProvider()) {
            ResultSet rs = provider.executeQuery(sql);
            while (rs.next()) {
                list.add(new KhachHangEntity(
                    rs.getString(MA_KH),
                    rs.getString(TEN_KH),
                    rs.getString(CMND),
                    rs.getString(SDT),
                    rs.getString(DIA_CHI),
                    rs.getDate(NGAY_NHAN) != null ? rs.getDate(NGAY_NHAN).toLocalDate() : null,
                    rs.getDate(NGAY_TRA) != null ? rs.getDate(NGAY_TRA).toLocalDate() : null
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(KhachHangSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    @Override
    public int addKhachHang(KhachHangEntity entity) {
        String sql = String.format("""
            INSERT INTO KhachHang (%s, %s, %s, %s, %s, %s, %s)
            VALUES ('%s', N'%s', '%s', '%s', N'%s', '%s', '%s')
            """,
            MA_KH, TEN_KH, CMND, SDT, DIA_CHI, NGAY_NHAN, NGAY_TRA,
            entity.maKH(), entity.tenKH(), entity.cmnd(),
            entity.sdt(), entity.diaChi(), entity.ngayNhan(), entity.ngayTra()
        );
        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(KhachHangSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public int updateKhachHang(KhachHangEntity entity) {
        String sql = String.format("""
            UPDATE KhachHang SET
                %s = N'%s', %s = '%s', 
                %s = '%s', %s = N'%s', %s = '%s', %s = '%s'
            WHERE %s = '%s'
            """,
            TEN_KH, entity.tenKH(), CMND, entity.cmnd(),
            SDT, entity.sdt(), DIA_CHI, entity.diaChi(),
            NGAY_NHAN, entity.ngayNhan(), NGAY_TRA, entity.ngayTra(),
            MA_KH, entity.maKH()
        );
        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(KhachHangSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public int deleteKhachHang(String maKH) {
        System.out.println(">>> Đã gọi đến KhachHangSQLServerService.deleteKhachHang với MaKH = " + maKH);
        String sql = String.format("DELETE FROM KhachHang WHERE MaKH = '%s'", maKH);
        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(KhachHangSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
}
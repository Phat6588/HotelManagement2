package databaseservice;

import entity.KhachHangEntity;
import java.util.List;

public interface IKhachHangDatabaseService {
    List<KhachHangEntity> getAllKhachHang();
    int addKhachHang(KhachHangEntity entity);
    int updateKhachHang(KhachHangEntity entity);
    int deleteKhachHang(String maKH);
}
package databaseservice;

import entity.NhanVienEntity;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NhanVienSQLServerService implements INhanVienDatabaseService {
    private static final String MA_NV = "MaNV";
    private static final String TEN_NV = "TenNV";
    private static final String CHUC_VU = "ChucVu";

    private static NhanVienSQLServerService instance;

    public static NhanVienSQLServerService getInstance() {
        if (instance == null) {
            instance = new NhanVienSQLServerService();
        }
        return instance;
    }

    private NhanVienSQLServerService() {}

    @Override
    public List<NhanVienEntity> getAllNhanViens() {
        List<NhanVienEntity> list = new ArrayList<>();
        String sql = "SELECT * FROM NhanVien";
        try (SQLServerProvider provider = new SQLServerProvider()) {
            ResultSet rs = provider.executeQuery(sql);
            while (rs.next()) {
                list.add(new NhanVienEntity(
                    rs.getString(MA_NV),
                    rs.getString(TEN_NV),
                    rs.getString(CHUC_VU)
                ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(NhanVienSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    @Override
    public int addNhanVien(NhanVienEntity nv) {
        String sql = String.format("""
            INSERT INTO NhanVien (%s, %s, %s)
            VALUES ('%s', N'%s', N'%s')
            """,
            MA_NV, TEN_NV, CHUC_VU,
            nv.maNV(), nv.tenNV(), nv.chucVu()
        );
        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(NhanVienSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public int updateNhanVien(NhanVienEntity nv) {
        String sql = String.format("""
            UPDATE NhanVien
            SET %s = N'%s', %s = N'%s'
            WHERE %s = '%s'
            """,
            TEN_NV, nv.tenNV(),
            CHUC_VU, nv.chucVu(),
            MA_NV, nv.maNV()
        );
        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(NhanVienSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    @Override
    public int deleteNhanVien(String maNV) {
        String sql = String.format("DELETE FROM NhanVien WHERE MaNV = '%s'", maNV);
        try (SQLServerProvider provider = new SQLServerProvider()) {
            return provider.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(NhanVienSQLServerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
}
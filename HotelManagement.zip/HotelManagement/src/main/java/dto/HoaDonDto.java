package dto;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

public class HoaDonDto {
    private String maHD;
    private String maKH;
    private String tenKH;
    private String maNV;
    private String tenNV;
    private String maPhong;
    private String tenPhong;
    private LocalDate ngayLapHD;
    private double tongTienPhong;
    private double tongTienDichVu;
    private double tongCong;
    private String ghiChu;
    private List<ChiTietHoaDon_DichVuDto> chiTietDichVu;
    private KhachHangDto khachHangDto;
    private NhanVienDto nhanVienDto;
    private RoomDto roomDto;

    // Constructor đầy đủ
    public HoaDonDto(String maHD, String maKH, String tenKH, String maNV, String tenNV, String maPhong, String tenPhong,
                     LocalDate ngayLapHD, double tongTienPhong, double tongTienDichVu,
                     double tongCong, String ghiChu, List<ChiTietHoaDon_DichVuDto> chiTietDichVu,
                     KhachHangDto khachHangDto, NhanVienDto nhanVienDto, RoomDto roomDto) {
        this.maHD = maHD;
        this.maKH = maKH;
        this.tenKH = tenKH;
        this.maNV = maNV;
        this.tenNV = tenNV;
        this.maPhong = maPhong;
        this.tenPhong = tenPhong;
        this.ngayLapHD = ngayLapHD;
        this.tongTienPhong = tongTienPhong;
        this.tongTienDichVu = tongTienDichVu;
        this.tongCong = tongCong;
        this.ghiChu = ghiChu;
        this.chiTietDichVu = chiTietDichVu != null ? chiTietDichVu : new ArrayList<>();
        this.khachHangDto = khachHangDto;
        this.nhanVienDto = nhanVienDto;
        this.roomDto = roomDto;
    }

    public HoaDonDto() {
        this.chiTietDichVu = new ArrayList<>();
    }

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getMaKH() {
        return maKH;
    }

    public void setMaKH(String maKH) {
        this.maKH = maKH;
    }

    public String getTenKH() {
        return tenKH;
    }

    public void setTenKH(String tenKH) {
        this.tenKH = tenKH;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public String getTenNV() {
        return tenNV;
    }

    public void setTenNV(String tenNV) {
        this.tenNV = tenNV;
    }
    
    public String getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(String maPhong) {
        this.maPhong = maPhong;
    }

    public String getTenPhong() {
        return tenPhong;
    }

    public void setTenPhong(String tenPhong) {
        this.tenPhong = tenPhong;
    }

    public LocalDate getNgayLapHD() {
        return ngayLapHD;
    }

    public void setNgayLapHD(LocalDate ngayLapHD) {
        this.ngayLapHD = ngayLapHD;
    }

    public double getTongTienPhong() {
        return tongTienPhong;
    }

    public void setTongTienPhong(double tongTienPhong) {
        this.tongTienPhong = tongTienPhong;
    }

    public double getTongTienDichVu() {
        return tongTienDichVu;
    }

    public void setTongTienDichVu(double tongTienDichVu) {
        this.tongTienDichVu = tongTienDichVu;
    }

    public double getTongCong() {
        return tongCong;
    }

    public void setTongCong(double tongCong) {
        this.tongCong = tongCong;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public List<ChiTietHoaDon_DichVuDto> getChiTietDichVu() {
        return chiTietDichVu;
    }

    public void setChiTietDichVu(List<ChiTietHoaDon_DichVuDto> chiTietDichVu) {
        this.chiTietDichVu = chiTietDichVu;
    }


    public KhachHangDto getKhachHangDto() {
        return khachHangDto;
    }

    public void setKhachHangDto(KhachHangDto khachHangDto) {
        this.khachHangDto = khachHangDto;
        if (khachHangDto != null) {
            this.maKH = khachHangDto.getMaKH();
            this.tenKH = khachHangDto.getTenKH();
        }
    }

    public NhanVienDto getNhanVienDto() {
        return nhanVienDto;
    }

    public void setNhanVienDto(NhanVienDto nhanVienDto) {
        this.nhanVienDto = nhanVienDto;
        if (nhanVienDto != null) {
            this.maNV = nhanVienDto.getMaNV();
            this.tenNV = nhanVienDto.getTenNV();
        }
    }
    
    public RoomDto getRoomDto() {
        return roomDto;
    }

    public void setRoomDto(RoomDto roomDto) {
        this.roomDto = roomDto;
        if (roomDto != null) {
            this.maPhong = roomDto.getMaPhong();
            this.tenPhong = roomDto.getTenPhong();
        }
    }
}
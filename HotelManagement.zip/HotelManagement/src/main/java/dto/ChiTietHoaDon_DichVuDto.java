package dto;

public class ChiTietHoaDon_DichVuDto {
    private String maHD;
    private String maDV;
    private String tenDV;
    private int soLuong;
    private double donGiaTaiThoiDiemSuDung;
    private double thanhTien;
    private DichVuDto dichVuDto; //

    public ChiTietHoaDon_DichVuDto() {
    }

    public ChiTietHoaDon_DichVuDto(String maHD, String maDV, String tenDV, int soLuong,
                                   double donGiaTaiThoiDiemSuDung, double thanhTien, DichVuDto dichVuDto) {
        this.maHD = maHD;
        this.maDV = maDV;
        this.tenDV = tenDV;
        this.soLuong = soLuong;
        this.donGiaTaiThoiDiemSuDung = donGiaTaiThoiDiemSuDung;
        this.thanhTien = thanhTien;
        this.dichVuDto = dichVuDto;
    }

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getMaDV() {
        return maDV;
    }

    public void setMaDV(String maDV) {
        this.maDV = maDV;
    }

    public String getTenDV() {
        return tenDV;
    }

    public void setTenDV(String tenDV) {
        this.tenDV = tenDV;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getDonGiaTaiThoiDiemSuDung() {
        return donGiaTaiThoiDiemSuDung;
    }

    public void setDonGiaTaiThoiDiemSuDung(double donGiaTaiThoiDiemSuDung) {
        this.donGiaTaiThoiDiemSuDung = donGiaTaiThoiDiemSuDung;
    }

    public double getThanhTien() {
        return thanhTien;
    }

    public void setThanhTien(double thanhTien) {
        this.thanhTien = thanhTien;
    }

    public DichVuDto getDichVuDto() {
        return dichVuDto;
    }

    public void setDichVuDto(DichVuDto dichVuDto) {
        this.dichVuDto = dichVuDto;
        if (dichVuDto != null) {
            this.maDV = dichVuDto.getMaDV(); //
            this.tenDV = dichVuDto.getTenDV(); //
        }
    }
}
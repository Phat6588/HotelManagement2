package dto;

import java.util.Date;

public class DonHangDto {

    String maDH;
    KhachHangDto khachHang;
    Date ngalyLapDH;
}

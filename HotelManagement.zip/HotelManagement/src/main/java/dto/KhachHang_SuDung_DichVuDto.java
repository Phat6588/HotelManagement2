package dto;

import java.time.LocalDate;

public class KhachHang_SuDung_DichVuDto {
    private int maKHSDDV;
    private String maKH;
    private String tenKH;
    private String maDV;
    private String tenDV;
    private LocalDate ngaySuDung;
    private int soLuong;
    private String ghiChu;
    private boolean daThanhToan;
    private String maHD;

    public KhachHang_SuDung_DichVuDto() {}

    public KhachHang_SuDung_DichVuDto(int maKHSDDV, String maKH, String tenKH, String maDV, String tenDV,
                                      LocalDate ngaySuDung, int soLuong, String ghiChu, boolean daThanhToan, String maHD) {
        this.maKHSDDV = maKHSDDV;
        this.maKH = maKH;
        this.tenKH = tenKH;
        this.maDV = maDV;
        this.tenDV = tenDV;
        this.ngaySuDung = ngaySuDung;
        this.soLuong = soLuong;
        this.ghiChu = ghiChu;
        this.daThanhToan = daThanhToan;
        this.maHD = maHD;
    }

    // Getters and Setters

    public int getMaKHSDDV() {
        return maKHSDDV;
    }

    public void setMaKHSDDV(int maKHSDDV) {
        this.maKHSDDV = maKHSDDV;
    }

    public String getMaKH() {
        return maKH;
    }

    public void setMaKH(String maKH) {
        this.maKH = maKH;
    }

    public String getTenKH() {
        return tenKH;
    }

    public void setTenKH(String tenKH) {
        this.tenKH = tenKH;
    }

    public String getMaDV() {
        return maDV;
    }

    public void setMaDV(String maDV) {
        this.maDV = maDV;
    }

    public String getTenDV() {
        return tenDV;
    }

    public void setTenDV(String tenDV) {
        this.tenDV = tenDV;
    }

    public LocalDate getNgaySuDung() {
        return ngaySuDung;
    }

    public void setNgaySuDung(LocalDate ngaySuDung) {
        this.ngaySuDung = ngaySuDung;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public boolean isDaThanhToan() {
        return daThanhToan;
    }

    public void setDaThanhToan(boolean daThanhToan) {
        this.daThanhToan = daThanhToan;
    }

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }
}
package model;

import com.mycompany.hotelmanagement.BHException;

public class Room {
    private String maPhong;
    private String tenPhong;
    private String tinhTrang;
    private double giaPhong;

    public Room(String maPhong, String tenPhong, String tinhTrang, double giaPhong) throws BHException {
        setMaPhong(maPhong);
        setTenPhong(tenPhong);
        setTinhTrang(tinhTrang);
        setGiaPhong(giaPhong);
    }

    public String getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(String maPhong) throws BHException {
        if (maPhong == null || maPhong.isBlank()) throw new BHException("Mã phòng không hợp lệ");
        this.maPhong = maPhong;
    }

    public String getTenPhong() {
        return tenPhong;
    }

    public void setTenPhong(String tenPhong) throws BHException {
        if (tenPhong == null || tenPhong.isBlank()) throw new BHException("Tên phòng không hợp lệ");
        this.tenPhong = tenPhong;
    }

    public String getTinhTrang() {
        return tinhTrang;
    }

    public void setTinhTrang(String tinhTrang) {
        this.tinhTrang = tinhTrang != null ? tinhTrang : "Trống";
    }

    public double getGiaPhong() {
        return giaPhong;
    }

    public void setGiaPhong(double giaPhong) throws BHException {
        if (giaPhong < 0) throw new BHException("Giá phòng phải >= 0");
        this.giaPhong = giaPhong;
    }
}
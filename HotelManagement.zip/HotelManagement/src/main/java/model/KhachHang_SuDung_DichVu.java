package model;

import com.mycompany.hotelmanagement.BHException;
import java.time.LocalDate;

public class KhachHang_SuDung_DichVu {
    private int maKHSDDV;
    private KhachHang khachHang;
    private DichVu dichVu;
    private LocalDate ngaySuDung;
    private int soLuong;
    private String ghiChu;
    private boolean daThanhToan;
    private HoaDon hoaDon;

    public KhachHang_SuDung_DichVu(int maKHSDDV, KhachHang khachHang, DichVu dichVu, 
                                   LocalDate ngaySuDung, int soLuong, String ghiChu, 
                                   boolean daThanhToan, HoaDon hoaDon) throws BHException {
        setMaKHSDDV(maKHSDDV);
        setKhachHang(khachHang);
        setDichVu(dichVu);
        setNgaySuDung(ngaySuDung);
        setSoLuong(soLuong);
        setGhiChu(ghiChu);
        setDaThanhToan(daThanhToan);
        setHoaDon(hoaDon);
    }

    public KhachHang_SuDung_DichVu(KhachHang khachHang, DichVu dichVu, LocalDate ngaySuDung, int soLuong) throws BHException {
        this(0, khachHang, dichVu, ngaySuDung, soLuong, null, false, null);
    }


    public int getMaKHSDDV() {
        return maKHSDDV;
    }

    public void setMaKHSDDV(int maKHSDDV) {
        this.maKHSDDV = maKHSDDV;
    }

    public KhachHang getKhachHang() {
        return khachHang;
    }

    public void setKhachHang(KhachHang khachHang) throws BHException {
        if (khachHang == null) throw new BHException("Khách hàng không được trống.");
        this.khachHang = khachHang;
    }

    public DichVu getDichVu() {
        return dichVu;
    }

    public void setDichVu(DichVu dichVu) throws BHException {
        if (dichVu == null) throw new BHException("Dịch vụ không được trống.");
        this.dichVu = dichVu;
    }

    public LocalDate getNgaySuDung() {
        return ngaySuDung;
    }

    public void setNgaySuDung(LocalDate ngaySuDung) throws BHException {
        if (ngaySuDung == null) throw new BHException("Ngày sử dụng không được trống.");
        this.ngaySuDung = ngaySuDung;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) throws BHException {
        if (soLuong <= 0) throw new BHException("Số lượng phải lớn hơn 0.");
        this.soLuong = soLuong;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public boolean isDaThanhToan() {
        return daThanhToan;
    }

    public void setDaThanhToan(boolean daThanhToan) {
        this.daThanhToan = daThanhToan;
    }

    public HoaDon getHoaDon() {
        return hoaDon;
    }

    public void setHoaDon(HoaDon hoaDon) {
        this.hoaDon = hoaDon;
    }
}
package model;

import com.mycompany.hotelmanagement.BHException;

public class NhanVien {
    private String maNV;
    private String tenNV;
    private String chucVu;

    public NhanVien(String maNV, String tenNV, String chucVu) throws BHException {
        setMaNV(maNV);
        setTenNV(tenNV);
        setChucVu(chucVu);
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) throws BHException {
        if (maNV == null || maNV.isBlank()) throw new BHException("Mã nhân viên không hợp lệ");
        this.maNV = maNV;
    }

    public String getTenNV() {
        return tenNV;
    }

    public void setTenNV(String tenNV) throws BHException {
        if (tenNV == null || tenNV.isBlank()) throw new BHException("Tên nhân viên không hợp lệ");
        this.tenNV = tenNV;
    }

    public String getChucVu() {
        return chucVu;
    }

    public void setChucVu(String chucVu) {
        this.chucVu = chucVu != null ? chucVu : "";
    }
}
package model;

import java.util.Date;

public class DonHang {

    String maDH;
    KhachHang khachHang;
    Date ngalyLapDH;
}

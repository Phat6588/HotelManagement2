package model;

import com.mycompany.hotelmanagement.BHException;
import java.time.LocalDate;

public class KhachHang {
    private String maKH;
    private String tenKH;
    private String cmnd;
    private String sdt;
    private String diaChi;
    private LocalDate ngayNhan;
    private LocalDate ngayTra;

    public KhachHang(String maKH, String tenKH, String cmnd,
                     String sdt, String diaChi, LocalDate ngayNhan, LocalDate ngayTra) throws BHException {
        setMaKH(maKH);
        setTenKH(tenKH);
        setCmnd(cmnd);
        setSdt(sdt);
        setDiaChi(diaChi);
        setNgayNhan(ngayNhan);
        setNgayTra(ngayTra);
    }

    public String getMaKH() {
        return maKH;
    }

    public void setMaKH(String maKH) throws BHException {
        if (maKH == null || maKH.isBlank()) throw new BHException("Mã khách hàng không hợp lệ");
        this.maKH = maKH;
    }

    public String getTenKH() {
        return tenKH;
    }

    public void setTenKH(String tenKH) {
        this.tenKH = tenKH;
    }

    public String getCmnd() {
        return cmnd;
    }

    public void setCmnd(String cmnd) {
        this.cmnd = cmnd;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public LocalDate getNgayNhan() {
        return ngayNhan;
    }

    public void setNgayNhan(LocalDate ngayNhan) {
        this.ngayNhan = ngayNhan;
    }

    public LocalDate getNgayTra() {
        return ngayTra;
    }   

    public void setNgayTra(LocalDate ngayTra) {
        this.ngayTra = ngayTra;
    }
}
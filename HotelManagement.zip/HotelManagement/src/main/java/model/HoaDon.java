package model;

import com.mycompany.hotelmanagement.BHException;
import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;

public class HoaDon {
    private String maHD;
    private KhachHang khachHang;
    private NhanVien nhanVien;
    private LocalDate ngayLapHD;
    private double tongTienPhong;
    private double tongTienDichVu;
    private double tongCong;
    private String ghiChu;
    private List<ChiTietHoaDon_DichVu> chiTietDichVu;

    public HoaDon(String maHD, KhachHang khachHang, NhanVien nhanVien, LocalDate ngayLapHD,
                  double tongTienPhong, double tongTienDichVu, String ghiChu) throws BHException {
        setMaHD(maHD);
        setKhachHang(khachHang);
        setNhanVien(nhanVien);
        setNgayLapHD(ngayLapHD);
        setTongTienPhong(tongTienPhong);
        setTongTienDichVu(tongTienDichVu);
        this.tongCong = this.tongTienPhong + this.tongTienDichVu;
        setGhiChu(ghiChu);
        this.chiTietDichVu = new ArrayList<>();
    }

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) throws BHException {
        if (maHD == null || maHD.trim().isEmpty()) {
            throw new BHException("Mã hóa đơn không hợp lệ.");
        }
        this.maHD = maHD;
    }

    public KhachHang getKhachHang() {
        return khachHang;
    }

    public void setKhachHang(KhachHang khachHang) throws BHException {
        if (khachHang == null) {
            throw new BHException("Khách hàng không được để trống.");
        }
        this.khachHang = khachHang;
    }

    public NhanVien getNhanVien() {
        return nhanVien;
    }

    public void setNhanVien(NhanVien nhanVien) throws BHException {
        if (nhanVien == null) {
            throw new BHException("Nhân viên không được để trống.");
        }
        this.nhanVien = nhanVien;
    }

    public LocalDate getNgayLapHD() {
        return ngayLapHD;
    }

    public void setNgayLapHD(LocalDate ngayLapHD) throws BHException {
        if (ngayLapHD == null) {
            throw new BHException("Ngày lập hóa đơn không được để trống.");
        }
        this.ngayLapHD = ngayLapHD;
    }

    public double getTongTienPhong() {
        return tongTienPhong;
    }

    public void setTongTienPhong(double tongTienPhong) throws BHException {
        if (tongTienPhong < 0) {
            throw new BHException("Tổng tiền phòng không hợp lệ.");
        }
        this.tongTienPhong = tongTienPhong;
        this.tongCong = this.tongTienPhong + this.tongTienDichVu;
    }

    public double getTongTienDichVu() {
        return tongTienDichVu;
    }

    public void setTongTienDichVu(double tongTienDichVu) throws BHException {
        if (tongTienDichVu < 0) {
            throw new BHException("Tổng tiền dịch vụ không hợp lệ.");
        }
        this.tongTienDichVu = tongTienDichVu;
        this.tongCong = this.tongTienPhong + this.tongTienDichVu;
    }

    public double getTongCong() {
        return tongCong;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public List<ChiTietHoaDon_DichVu> getChiTietDichVu() {
        return chiTietDichVu;
    }

    public void setChiTietDichVu(List<ChiTietHoaDon_DichVu> chiTietDichVu) {
        this.chiTietDichVu = chiTietDichVu != null ? chiTietDichVu : new ArrayList<>();
    }

    public void themChiTietDichVu(ChiTietHoaDon_DichVu chiTiet) throws BHException {
        if (chiTiet == null) {
            throw new BHException("Chi tiết dịch vụ không hợp lệ để thêm vào hóa đơn.");
        }
        this.chiTietDichVu.add(chiTiet);
    }
}
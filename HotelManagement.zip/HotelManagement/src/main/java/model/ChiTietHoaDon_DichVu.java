package model;

import com.mycompany.hotelmanagement.BHException;

public class ChiTietHoaDon_DichVu {
    private DichVu dichVu;
    private int soLuong;
    private double donGiaTaiThoiDiemSuDung;
    private double thanhTien;

    public ChiTietHoaDon_DichVu(DichVu dichVu, int soLuong, double donGiaTaiThoiDiemSuDung) throws BHException {
        setDichVu(dichVu);
        setSoLuong(soLuong);
        setDonGiaTaiThoiDiemSuDung(donGiaTaiThoiDiemSuDung);
        this.thanhTien = this.soLuong * this.donGiaTaiThoiDiemSuDung;
    }

    public DichVu getDichVu() {
        return dichVu;
    }

    public void setDichVu(DichVu dichVu) throws BHException {
        if (dichVu == null) {
            throw new BHException("Dịch vụ trong chi tiết hóa đơn không được để trống.");
        }
        this.dichVu = dichVu;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) throws BHException {
        if (soLuong <= 0) {
            throw new BHException("Số lượng dịch vụ phải lớn hơn 0.");
        }
        this.soLuong = soLuong;
        this.thanhTien = this.soLuong * this.donGiaTaiThoiDiemSuDung;
    }

    public double getDonGiaTaiThoiDiemSuDung() {
        return donGiaTaiThoiDiemSuDung;
    }

    public void setDonGiaTaiThoiDiemSuDung(double donGiaTaiThoiDiemSuDung) throws BHException {
        if (donGiaTaiThoiDiemSuDung < 0) {
            throw new BHException("Đơn giá dịch vụ tại thời điểm sử dụng không hợp lệ.");
        }
        this.donGiaTaiThoiDiemSuDung = donGiaTaiThoiDiemSuDung;
        this.thanhTien = this.soLuong * this.donGiaTaiThoiDiemSuDung;
    }

    public double getThanhTien() {
        return thanhTien;
    }
}
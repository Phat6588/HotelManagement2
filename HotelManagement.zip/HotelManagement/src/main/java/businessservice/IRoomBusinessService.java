/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessservice;
import dto.RoomDto;
import java.util.List;
import service.RoomService;

public interface IRoomBusinessService {
    List<RoomDto> getAllRooms();
    boolean addRoom(RoomDto dto);
    boolean updateRoom(RoomDto dto);
    boolean deleteRoom(String maPhong);
    List<String> getAllRoomIds();
}


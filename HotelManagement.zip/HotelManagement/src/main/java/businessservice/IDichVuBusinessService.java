/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessservice;
import dto.DichVuDto;
import java.util.List;


public interface IDichVuBusinessService {
    List<DichVuDto> getAllDichVus();
    boolean addDichVu(DichVuDto dto);
    boolean updateDichVu(DichVuDto dto);
    boolean deleteDichVu(String maDV); 
       List<String> getAllDichVuIds();
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package businessservice;

import com.mycompany.hotelmanagement.BHException;
import dto.RoomDto;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Room;
import service.RoomService;

public class RoomBusinessService implements IRoomBusinessService {

    private static RoomBusinessService instance;
    private RoomService roomService;

    public static RoomBusinessService getInstance() {
        if (instance == null) {
            instance = new RoomBusinessService();
        }
        return instance;
    }

    private RoomBusinessService() {
        roomService = RoomService.getInstance();
    }
@Override
public List<String> getAllRoomIds() {
    List<String> maPhongList = new ArrayList<>();
    for (Room model : RoomService.getInstance().getRoomList()) {
        maPhongList.add(model.getMaPhong());
    }
    return maPhongList;
}
    @Override
    public List<RoomDto> getAllRooms() {
        List<RoomDto> list = new ArrayList<>();
        for (Room model : RoomService.getInstance().getRoomList()) {
            list.add(toDto(model));
        }
        return list;
    }

    @Override
    public boolean addRoom(RoomDto dto) {
        try {
            return roomService.addRoom(toModel(dto));
        } catch (BHException ex) {
            Logger.getLogger(RoomBusinessService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean updateRoom(RoomDto dto) {
        try {
            return RoomService.getInstance().updateRoom(toModel(dto));
        } catch (BHException ex) {
            Logger.getLogger(RoomBusinessService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
@Override
public boolean deleteRoom(String maPhong) {
    return RoomService.getInstance().deleteRoom(maPhong);
}

    private Room toModel(RoomDto dto) throws BHException {
        return new Room(dto.getMaPhong(), dto.getTenPhong(), dto.getTinhTrang(), dto.getGiaPhong());
    }

    private RoomDto toDto(Room model) {
        return new RoomDto(model.getMaPhong(), model.getTenPhong(), model.getTinhTrang(), model.getGiaPhong());
    }
}

package businessservice;

import dto.KhachHangDto;
import java.util.List;

public interface IKhachHangBusinessService {
    List<KhachHangDto> getAllKhachHang();
    boolean addKhachHang(KhachHangDto dto);
    boolean updateKhachHang(KhachHangDto dto);
    boolean deleteKhachHang(String maKH);
}
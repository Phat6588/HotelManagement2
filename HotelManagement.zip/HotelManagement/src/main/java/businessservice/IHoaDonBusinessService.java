package businessservice;

import dto.ChiTietHoaDon_DichVuDto;
import dto.HoaDonDto;
import dto.KhachHangDto;
import java.util.List;

public interface IHoaDonBusinessService {
    List<HoaDonDto> getAllHoaDon();
    HoaDonDto getHoaDonById(String maHD);
    boolean createHoaDon(HoaDonDto hoaDonDto);

    List<ChiTietHoaDon_DichVuDto> getAllChiTietHoaDonByMaHD(String maHD);
    
    double tinhTienPhong(String maPhong, java.time.LocalDate ngayNhan, java.time.LocalDate ngayTra);
    double tinhTongTienDichVu(List<ChiTietHoaDon_DichVuDto> chiTietDichVuList);
    
    String taoMaHoaDonMoi();
}
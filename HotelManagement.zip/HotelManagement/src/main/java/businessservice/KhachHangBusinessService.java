package businessservice;

import com.mycompany.hotelmanagement.BHException;
import dto.KhachHangDto;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.KhachHang;
import service.KhachHangService;

public class KhachHangBusinessService implements IKhachHangBusinessService {

    private static KhachHangBusinessService instance;
    private final KhachHangService khachHangService;

    public static KhachHangBusinessService getInstance() {
        if (instance == null) {
            instance = new KhachHangBusinessService();
        }
        return instance;
    }

    private KhachHangBusinessService() {
        khachHangService = KhachHangService.getInstance();
    }

    @Override
    public List<KhachHangDto> getAllKhachHang() {
        List<KhachHangDto> list = new ArrayList<>();
        for (KhachHang model : KhachHangService.getInstance().getKhachHangList()) {
            list.add(toDto(model));
        }
        return list;
    }

    @Override
    public boolean addKhachHang(KhachHangDto dto) {
        try {
            return khachHangService.addKhachHang(toModel(dto));
        } catch (BHException ex) {
            Logger.getLogger(KhachHangBusinessService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean updateKhachHang(KhachHangDto dto) {
        try {
            return khachHangService.updateKhachHang(toModel(dto));
        } catch (BHException ex) {
            Logger.getLogger(KhachHangBusinessService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean deleteKhachHang(String maKH) {
        System.out.println(">>> Gọi KhachHangBusinessService.deleteKhachHang với MaKH = " + maKH);
        return khachHangService.deleteKhachHang(maKH);
    }

    private KhachHang toModel(KhachHangDto dto) throws BHException {
        return new KhachHang(
                dto.getMaKH(),
                dto.getTenKH(),
                dto.getCmnd(),
                dto.getSdt(),
                dto.getDiaChi(),
                dto.getNgayNhan(),
                dto.getNgayTra()
        );
    }

    private KhachHangDto toDto(KhachHang model) {
        return new KhachHangDto(
                model.getMaKH(),
                model.getTenKH(),
                model.getCmnd(),
                model.getSdt(),
                model.getDiaChi(),
                model.getNgayNhan(),
                model.getNgayTra()
        );
    }
}
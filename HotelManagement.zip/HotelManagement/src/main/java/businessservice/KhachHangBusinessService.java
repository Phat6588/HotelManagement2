package businessservice;

import com.mycompany.hotelmanagement.BHException;
import dto.KhachHangDto;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.KhachHang;
import service.KhachHangService;

public class KhachHangBusinessService implements IKhachHangBusinessService {

    private static KhachHangBusinessService instance;

    public static KhachHangBusinessService getInstance() {
        if (instance == null) {
            instance = new KhachHangBusinessService();
        }
        return instance;
    }

    private KhachHangBusinessService() {
    }

    @Override
    public List<KhachHangDto> getAllKhachHang() {
        List<KhachHangDto> list = new ArrayList<>();
        for (KhachHang model : KhachHangService.getInstance().getKhachHangList()) {
            list.add(toDto(model));
        }
        return list;
    }

    @Override
    public boolean addKhachHang(KhachHangDto dto) {
        try {
            boolean result = KhachHangService.getInstance().addKhachHang(toModel(dto));
            if (result) {
                // load lại dữ liệu mới từ DB
                KhachHangService.getInstance().loadAllKhachHangFromDatabase();
            }
            return result;
        } catch (BHException ex) {
            Logger.getLogger(KhachHangBusinessService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean updateKhachHang(KhachHangDto dto) {
        try {
            boolean result = KhachHangService.getInstance().updateKhachHang(toModel(dto));
            if (result) {
                KhachHangService.getInstance().loadAllKhachHangFromDatabase();
            }
            return result;
        } catch (BHException ex) {
            Logger.getLogger(KhachHangBusinessService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

    @Override
    public boolean deleteKhachHang(String maKH) {
        System.out.println(">>> Gọi KhachHangBusinessService.deleteKhachHang với MaKH = " + maKH);
        boolean result = KhachHangService.getInstance().deleteKhachHang(maKH);
        if (result) {
            KhachHangService.getInstance().loadAllKhachHangFromDatabase();
        }
        return result;
    }

    private KhachHang toModel(KhachHangDto dto) throws BHException {
        return new KhachHang(
                dto.getMaKH(),
                dto.getTenKH(),
                dto.getCmnd(),
                dto.getSdt(),
                dto.getDiaChi(),
                dto.getNgayNhan(),
                dto.getNgayTra()
        );
    }

    private KhachHangDto toDto(KhachHang model) {
        return new KhachHangDto(
                model.getMaKH(),
                model.getTenKH(),
                model.getCmnd(),
                model.getSdt(),
                model.getDiaChi(),
                model.getNgayNhan(),
                model.getNgayTra()
        );
    }
}
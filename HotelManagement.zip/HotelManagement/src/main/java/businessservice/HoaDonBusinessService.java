package businessservice;

import com.mycompany.hotelmanagement.BHException;
import dto.ChiTietHoaDon_DichVuDto;
import dto.DichVuDto;
import dto.HoaDonDto;
import dto.KhachHangDto;
import dto.NhanVienDto;
import dto.RoomDto;
import model.ChiTietHoaDon_DichVu;
import model.DichVu; 
import model.HoaDon;
import model.KhachHang;
import model.NhanVien;
import model.Room;
import service.DichVuService;
import service.HoaDonService;
import service.KhachHangService;
import service.NhanVienService;
import service.RoomService;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class HoaDonBusinessService implements IHoaDonBusinessService {

    private static HoaDonBusinessService instance;
    private HoaDonService hoaDonService;
    private KhachHangService khachHangService;
    private NhanVienService nhanVienService;
    private DichVuService dichVuService;
    private RoomService roomService;


    public static HoaDonBusinessService getInstance() {
        if (instance == null) {
            instance = new HoaDonBusinessService();
        }
        return instance;
    }

    private HoaDonBusinessService() {
        this.hoaDonService = HoaDonService.getInstance();
        this.khachHangService = KhachHangService.getInstance();
        this.nhanVienService = NhanVienService.getInstance();
        this.dichVuService = DichVuService.getInstance();
        this.roomService = RoomService.getInstance();
    }

    @Override
    public List<HoaDonDto> getAllHoaDon() {
        return hoaDonService.getAllHoaDon().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Override
    public HoaDonDto getHoaDonById(String maHD) {
        try {
            HoaDon model = hoaDonService.getHoaDonById(maHD);
            return model != null ? toDto(model) : null;
        } catch (BHException ex) {
            Logger.getLogger(HoaDonBusinessService.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    @Override
    public boolean createHoaDon(HoaDonDto dto) {
        try {
            if (dto.getMaKH() == null || dto.getMaNV() == null || dto.getNgayLapHD() == null) {
                 Logger.getLogger(HoaDonBusinessService.class.getName()).log(Level.WARNING, "Thông tin cơ bản của hóa đơn bị thiếu.");
                return false;
            }
            return hoaDonService.createHoaDon(toModel(dto));
        } catch (BHException ex) {
            Logger.getLogger(HoaDonBusinessService.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    @Override
    public List<ChiTietHoaDon_DichVuDto> getAllChiTietHoaDonByMaHD(String maHD) {
        try {
            HoaDon hoaDon = hoaDonService.getHoaDonById(maHD);
            if (hoaDon != null && hoaDon.getChiTietDichVu() != null) {
                return hoaDon.getChiTietDichVu().stream()
                             .map(ctModel -> toChiTietDto(ctModel, maHD))
                             .collect(Collectors.toList());
            }
        } catch (BHException ex) {
            Logger.getLogger(HoaDonBusinessService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return new ArrayList<>();
    }


    @Override
    public double tinhTienPhong(String maPhong, LocalDate ngayNhan, LocalDate ngayTra) {
        if (maPhong == null || ngayNhan == null || ngayTra == null || ngayTra.isBefore(ngayNhan)) {
            return 0;
        }
        Room room = roomService.getRoomList().stream()
                .filter(r -> r.getMaPhong().equals(maPhong))
                .findFirst().orElse(null);
        if (room == null) {
            return 0;
        }
        long soNgayThue = ChronoUnit.DAYS.between(ngayNhan, ngayTra);
        if (soNgayThue == 0) soNgayThue = 1;
        return soNgayThue * room.getGiaPhong();
    }

    @Override
    public double tinhTongTienDichVu(List<ChiTietHoaDon_DichVuDto> chiTietDichVuList) {
        if (chiTietDichVuList == null) {
            return 0;
        }
        double tong = 0;
        for (ChiTietHoaDon_DichVuDto ct : chiTietDichVuList) {
            tong += ct.getThanhTien();
        }
        return tong;
    }
    
    @Override
    public String taoMaHoaDonMoi() {
        return "HD-" + System.currentTimeMillis() % 100000;
    }

    private HoaDon toModel(HoaDonDto dto) throws BHException {
        if (dto == null) return null;

        KhachHang kh = khachHangService.getKhachHangList().stream()
                .filter(k -> k.getMaKH().equals(dto.getMaKH()))
                .findFirst().orElse(null);
        if (kh == null && dto.getKhachHangDto() != null) {
             kh = new KhachHang(dto.getKhachHangDto().getMaKH(),
                                dto.getKhachHangDto().getTenKH(),
                                dto.getKhachHangDto().getCmnd(),
                                dto.getKhachHangDto().getSdt(),
                                dto.getKhachHangDto().getDiaChi(),
                                dto.getKhachHangDto().getNgayNhan(),
                                dto.getKhachHangDto().getNgayTra());
        }
         if (kh == null) throw new BHException("Không tìm thấy Khách hàng hợp lệ để tạo hóa đơn.");


        NhanVien nv = nhanVienService.getNhanVienList().stream()
                .filter(n -> n.getMaNV().equals(dto.getMaNV()))
                .findFirst().orElse(null);
        if (nv == null && dto.getNhanVienDto() != null) {
            nv = new NhanVien(dto.getNhanVienDto().getMaNV(), dto.getNhanVienDto().getTenNV(), dto.getNhanVienDto().getChucVu()); //
        }
        if (nv == null) throw new BHException("Không tìm thấy nhân viên hợp lệ để tạo hóa đơn.");

        HoaDon model = new HoaDon(
                dto.getMaHD(),
                kh,
                nv,
                dto.getNgayLapHD(),
                dto.getTongTienPhong(),
                dto.getTongTienDichVu(),
                dto.getGhiChu()
        );
        
        if (dto.getChiTietDichVu() != null) {
            List<ChiTietHoaDon_DichVu> chiTietModels = new ArrayList<>();
            for (ChiTietHoaDon_DichVuDto ctDto : dto.getChiTietDichVu()) {
                chiTietModels.add(toChiTietModel(ctDto));
            }
            model.setChiTietDichVu(chiTietModels);
        }
        return model;
    }

    private HoaDonDto toDto(HoaDon model) {
        if (model == null) return null;
        KhachHangDto khDto = null;
        if (model.getKhachHang() != null) {
            KhachHang khModel = model.getKhachHang();
            khDto = new KhachHangDto(khModel.getMaKH(),
                                   khModel.getTenKH(), khModel.getCmnd(), khModel.getSdt(),
                                   khModel.getDiaChi(), khModel.getNgayNhan(), khModel.getNgayTra());
        }

        NhanVienDto nvDto = null;
        if (model.getNhanVien() != null) {
            NhanVien nvModel = model.getNhanVien();
            nvDto = new NhanVienDto(nvModel.getMaNV(), nvModel.getTenNV(), nvModel.getChucVu());
        }
        
        List<ChiTietHoaDon_DichVuDto> chiTietDtos = new ArrayList<>();
        if(model.getChiTietDichVu() != null) {
            for(ChiTietHoaDon_DichVu ctModel : model.getChiTietDichVu()){
                chiTietDtos.add(toChiTietDto(ctModel, model.getMaHD()));
            }
        }

        return new HoaDonDto(
                model.getMaHD(),
                model.getKhachHang() != null ? model.getKhachHang().getMaKH() : null,
                model.getKhachHang() != null ? model.getKhachHang().getTenKH() : null,
                model.getNhanVien() != null ? model.getNhanVien().getMaNV() : null,
                model.getNhanVien() != null ? model.getNhanVien().getTenNV() : null,
                model.getNgayLapHD(),
                model.getTongTienPhong(),
                model.getTongTienDichVu(),
                model.getTongCong(),
                model.getGhiChu(),
                chiTietDtos,
                khDto,
                nvDto
        );
    }
    
    private ChiTietHoaDon_DichVu toChiTietModel(ChiTietHoaDon_DichVuDto dto) throws BHException {
        if (dto == null) return null;
        DichVu dv = dichVuService.getDichVuList().stream()
                .filter(d -> d.getMaDV().equals(dto.getMaDV()))
                .findFirst().orElse(null);
         if (dv == null && dto.getDichVuDto() != null) {
            dv = new DichVu(dto.getDichVuDto().getMaDV(), dto.getDichVuDto().getTenDV(), dto.getDichVuDto().getDonGia()); //
        }
        if (dv == null) throw new BHException("Dịch vụ không hợp lệ để tạo chi tiết hóa đơn.");

        return new ChiTietHoaDon_DichVu(
                dv,
                dto.getSoLuong(),
                dto.getDonGiaTaiThoiDiemSuDung() 
        );
    }

    private ChiTietHoaDon_DichVuDto toChiTietDto(ChiTietHoaDon_DichVu model, String maHD) {
        if (model == null) return null;
        DichVuDto dvDto = null;
        if(model.getDichVu() != null){
            dvDto = new DichVuDto(model.getDichVu().getMaDV(), model.getDichVu().getTenDV(), model.getDichVu().getDonGia()); //
        }
        return new ChiTietHoaDon_DichVuDto(
                maHD,
                model.getDichVu() != null ? model.getDichVu().getMaDV() : null,
                model.getDichVu() != null ? model.getDichVu().getTenDV() : null,
                model.getSoLuong(),
                model.getDonGiaTaiThoiDiemSuDung(),
                model.getThanhTien(),
                dvDto
        );
    }
}
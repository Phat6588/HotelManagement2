package businessservice;

import dto.NhanVienDto;
import java.util.List;

public interface INhanVienBusinessService {
    List<NhanVienDto> getAllNhanViens();
    boolean addNhanVien(NhanVienDto nv);
    boolean updateNhanVien(NhanVienDto nv);
    boolean deleteNhanVien(String maNV);
}
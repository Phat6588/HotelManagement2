package service;

import com.mycompany.hotelmanagement.BHException;
import databaseservice.INhanVienDatabaseService;
import entity.NhanVienEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.NhanVien;

public class NhanVienService {
    private static NhanVienService instance;

    public static NhanVienService getInstance() {
        if (instance == null) {
            instance = new NhanVienService();
        }
        return instance;
    }

    private final List<NhanVien> nhanVienList = new ArrayList<>();
    private INhanVienDatabaseService databaseService;

    public void setDatabaseService(INhanVienDatabaseService service) {
        this.databaseService = service;
    }

    public List<NhanVien> getNhanVienList() {
        return nhanVienList;
    }

    public void loadAllNhanViensFromDatabase() {
        nhanVienList.clear();
        for (NhanVienEntity entity : databaseService.getAllNhanViens()) {
            try {
                nhanVienList.add(toModel(entity));
            } catch (BHException ex) {
                Logger.getLogger(NhanVienService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public boolean addNhanVien(NhanVien nv) {
        return databaseService.addNhanVien(toEntity(nv)) > 0;
    }

    public boolean updateNhanVien(NhanVien nv) {
        return databaseService.updateNhanVien(toEntity(nv)) > 0;
    }

    public boolean deleteNhanVien(String maNV) {
        return databaseService.deleteNhanVien(maNV) > 0;
    }

    public NhanVienEntity toEntity(NhanVien nv) {
        return new NhanVienEntity(nv.getMaNV(), nv.getTenNV(), nv.getChucVu());
    }

    public NhanVien toModel(NhanVienEntity entity) throws BHException {
        return new NhanVien(entity.maNV(), entity.tenNV(), entity.chucVu());
    }
}
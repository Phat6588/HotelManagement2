package service;

import com.mycompany.hotelmanagement.BHException;
import databaseservice.IRoomDatabaseService;
import entity.RoomEntity;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Room;

public class RoomService {
    private static RoomService instance;

    public static RoomService getInstance() {
        if (instance == null) {
            instance = new RoomService();
        }
        return instance;
    }

    private final List<Room> roomList;
    private IRoomDatabaseService roomDatabaseService;

    private RoomService() {
        this.roomList = new ArrayList<>();
    }

    public List<Room> getRoomList() {
        return roomList;
    }

    public void setRoomDatabaseService(IRoomDatabaseService roomDatabaseService) {
        this.roomDatabaseService = roomDatabaseService;
    }

    public void loadAllRoomsFromDatabase() {
        this.roomList.clear();
        List<RoomEntity> entityList = this.roomDatabaseService.getAllRooms();
        for (RoomEntity entity : entityList) {
            try {
                this.roomList.add(toModel(entity));
            } catch (BHException ex) {
                Logger.getLogger(RoomService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public boolean addRoom(Room model) {
        return this.roomDatabaseService.addRoom(toEntity(model)) > 0;
    }
    public boolean updateRoom(Room model) {
    if (this.roomDatabaseService == null) {
        throw new IllegalStateException("roomDatabaseService chưa được khởi tạo");
    }
    return this.roomDatabaseService.updateRoom(toEntity(model)) > 0;
}
    
  public boolean deleteRoom(String maPhong) {
    return roomDatabaseService.deleteRoom(maPhong) > 0;
}
   

    public Room toModel(RoomEntity entity) throws BHException {
        return new Room(
                entity.maPhong(),
                entity.tenPhong(),
                entity.tinhTrang(),
                entity.giaPhong()
        );
    }

    public RoomEntity toEntity(Room model) {
        return new RoomEntity(
                model.getMaPhong(),
                model.getTenPhong(),
                model.getTinhTrang(),
                model.getGiaPhong()
        );
    }
}
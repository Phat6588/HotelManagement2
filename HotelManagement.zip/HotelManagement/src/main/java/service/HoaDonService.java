package service;

import com.mycompany.hotelmanagement.BHException;
import databaseservice.HoaDonSQLServerService;
import databaseservice.IHoaDonDatabaseService;
import entity.ChiTietHoaDon_DichVuEntity;
import entity.HoaDonEntity;
import model.ChiTietHoaDon_DichVu;
import model.DichVu;
import model.HoaDon;
import model.KhachHang;
import model.NhanVien;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class HoaDonService {
    private static HoaDonService instance;
    private IHoaDonDatabaseService hoaDonDatabaseService;
    private KhachHangService khachHangService;
    private NhanVienService nhanVienService;
    private DichVuService dichVuService;

    public static HoaDonService getInstance() {
        if (instance == null) {
            instance = new HoaDonService();
        }
        return instance;
    }

    private HoaDonService() {
        this.hoaDonDatabaseService = HoaDonSQLServerService.getInstance();
        this.khachHangService = KhachHangService.getInstance();
        this.nhanVienService = NhanVienService.getInstance();
        this.dichVuService = DichVuService.getInstance();
    }

    public void setHoaDonDatabaseService(IHoaDonDatabaseService hoaDonDatabaseService) {
        this.hoaDonDatabaseService = hoaDonDatabaseService;
    }

    public List<HoaDon> getAllHoaDon() {
        List<HoaDonEntity> entities = hoaDonDatabaseService.getAllHoaDon();
        List<HoaDon> models = new ArrayList<>();
        for (HoaDonEntity entity : entities) {
            try {
                models.add(toModel(entity));
            } catch (BHException ex) {
                Logger.getLogger(HoaDonService.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return models;
    }

    public HoaDon getHoaDonById(String maHD) throws BHException {
        HoaDonEntity entity = hoaDonDatabaseService.getHoaDonById(maHD);
        return entity != null ? toModel(entity) : null;
    }

    public boolean createHoaDon(HoaDon hoaDon) {
        if (hoaDon == null) return false;
        boolean hoaDonAdded = hoaDonDatabaseService.addHoaDon(toEntity(hoaDon)) > 0;
        if (hoaDonAdded) {
            for (ChiTietHoaDon_DichVu chiTiet : hoaDon.getChiTietDichVu()) {
                hoaDonDatabaseService.addChiTietHoaDon_DichVu(toChiTietEntity(chiTiet, hoaDon.getMaHD()));
            }
        }
        return hoaDonAdded;
    }
    
    private HoaDonEntity toEntity(HoaDon model) {
        if (model == null) return null;
        return new HoaDonEntity(
                model.getMaHD(),
                model.getKhachHang().getMaKH(),
                model.getNhanVien().getMaNV(),
                model.getNgayLapHD(),
                model.getTongTienPhong(),
                model.getTongTienDichVu(),
                model.getTongCong(),
                model.getGhiChu()
        );
    }

    private HoaDon toModel(HoaDonEntity entity) throws BHException {
        if (entity == null) return null;

        KhachHang kh = khachHangService.getKhachHangList().stream()
                .filter(k -> k.getMaKH().equals(entity.maKH()))
                .findFirst().orElse(null);
        if (kh == null) throw new BHException("Không tìm thấy khách hàng với mã: " + entity.maKH());

        NhanVien nv = nhanVienService.getNhanVienList().stream()
                .filter(n -> n.getMaNV().equals(entity.maNV()))
                .findFirst().orElse(null);
        if (nv == null) throw new BHException("Không tìm thấy nhân viên với mã: " + entity.maNV());

        HoaDon model = new HoaDon(
                entity.maHD(),
                kh,
                nv,
                entity.ngayLapHD(),
                entity.tongTienPhong(),
                entity.tongTienDichVu(),
                entity.ghiChu()
        );
        
        List<ChiTietHoaDon_DichVuEntity> chiTietEntities = hoaDonDatabaseService.getAllChiTietHoaDonByMaHD(entity.maHD());
        List<ChiTietHoaDon_DichVu> chiTietModels = new ArrayList<>();
        for(ChiTietHoaDon_DichVuEntity ctEntity : chiTietEntities) {
            chiTietModels.add(toChiTietModel(ctEntity));
        }
        model.setChiTietDichVu(chiTietModels);
        return model;
    }

    private ChiTietHoaDon_DichVuEntity toChiTietEntity(ChiTietHoaDon_DichVu model, String maHD) {
        if (model == null) return null;
        return new ChiTietHoaDon_DichVuEntity(
                maHD,
                model.getDichVu().getMaDV(),
                model.getSoLuong(),
                model.getDonGiaTaiThoiDiemSuDung(),
                model.getThanhTien()
        );
    }
    
    private ChiTietHoaDon_DichVu toChiTietModel(ChiTietHoaDon_DichVuEntity entity) throws BHException {
        if (entity == null) return null;
        DichVu dv = dichVuService.getDichVuList().stream()
                .filter(d -> d.getMaDV().equals(entity.maDV()))
                .findFirst().orElse(null);
        if (dv == null) throw new BHException("Không tìm thấy dịch vụ với mã: " + entity.maDV());
        
        return new ChiTietHoaDon_DichVu(dv, entity.soLuong(), entity.donGiaTaiThoiDiemSuDung());
    }
}
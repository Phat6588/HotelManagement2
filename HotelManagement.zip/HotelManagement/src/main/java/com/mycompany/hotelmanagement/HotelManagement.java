/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.hotelmanagement;

import businessservice.DichVuBusinessService;
import businessservice.IDichVuBusinessService;
import businessservice.IKhachHangBusinessService;
import businessservice.INhanVienBusinessService;
import businessservice.IRoomBusinessService;
import businessservice.KhachHangBusinessService;
import businessservice.NhanVienBusinessService;
import javax.swing.*;
import businessservice.RoomBusinessService;
import databaseservice.DichVuSQLServerService;
import databaseservice.IDichVuDatabaseService;
import databaseservice.IKhachHangDatabaseService;
import databaseservice.INhanVienDatabaseService;
import databaseservice.IRoomDatabaseService;
import databaseservice.KhachHangSQLServerService;
import databaseservice.RoomSQLServerService;
import java.util.ArrayList;
import java.util.List;
import model.DichVu;
import model.Room;
import service.DichVuService;
import service.KhachHangService;
import service.NhanVienService;
import service.RoomService;
import ui.NhanVienManagement;
import ui.RoomManagement;
import ui.ServiceManagement;
import ui.UserManagement;

import businessservice.IHoaDonBusinessService;
import businessservice.HoaDonBusinessService;
import databaseservice.IHoaDonDatabaseService;
import databaseservice.HoaDonSQLServerService;
import service.HoaDonService;
import ui.HoaDonManagement;
import ui.UserManagement;

public class HotelManagement extends JFrame {

    private IRoomDatabaseService roomDatabaseService;
    private IRoomBusinessService roomBusinessService;
    private RoomService roomService;

    private IDichVuDatabaseService dvDatabaseService;
    private IDichVuBusinessService dvBusinessService;
    private DichVuService dvService;

    private IKhachHangDatabaseService khachHangDatabaseService;
    private IKhachHangBusinessService khachHangBusinessService;
    private KhachHangService khachHangService;

    private INhanVienDatabaseService nhanVienDatabaseService;
    private INhanVienBusinessService nhanVienBusinessService;
    private NhanVienService nhanVienService;
    
    private IHoaDonDatabaseService hoaDonDatabaseService;
    private HoaDonService hoaDonServiceInstance;
    private IHoaDonBusinessService hoaDonBusinessService;
    

    public static void main(String[] args) {
        System.out.println("Quản lí khách sạn");
        HotelManagement app = new HotelManagement();
        app.process();

        app.setExtendedState(JFrame.MAXIMIZED_BOTH); // Chỉnh full screen
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        app.setUndecorated(false);
        app.setVisible(true);
    }

    private void process() {
        Room();
        Service();
        KhachHang();
        NhanVien();
        HoaDon();

        JTabbedPane tabbedPane = new JTabbedPane();

        RoomManagement roomManagement = new RoomManagement();
        roomManagement.setRoomBusinessService(this.roomBusinessService);
        tabbedPane.addTab("Quản lý phòng", roomManagement);

        ServiceManagement serviceManagement = new ServiceManagement();
        serviceManagement.setDichVuBusinessService(this.dvBusinessService);
        tabbedPane.addTab("Quản lý dịch vụ", serviceManagement);

        UserManagement userManagement = new UserManagement();
        userManagement.setKhachHangBusinessService(this.khachHangBusinessService);
        
        tabbedPane.addTab("Quản lý khách hàng", userManagement);

        NhanVienManagement employeeManagement = new NhanVienManagement();
        employeeManagement.setNhanVienBusinessService(this.nhanVienBusinessService);
        tabbedPane.addTab("Quản lý nhân viên", employeeManagement);

        HoaDonManagement hoaDonManagementPanel = new HoaDonManagement();
        hoaDonManagementPanel.initServices(
            this.khachHangBusinessService,
            this.nhanVienBusinessService,
            this.dvBusinessService,
            this.roomBusinessService
        );
        tabbedPane.addTab("Quản lý Hóa Đơn", hoaDonManagementPanel);

        this.setContentPane(tabbedPane);
        this.revalidate();
        this.repaint();
    }

    private void Room() {

        roomDatabaseService = RoomSQLServerService.getInstance();
        roomService = RoomService.getInstance();
        roomService.setRoomDatabaseService(roomDatabaseService);
        roomService.loadAllRoomsFromDatabase();
        roomBusinessService = RoomBusinessService.getInstance();
    }

    private void Service() {

        dvDatabaseService = DichVuSQLServerService.getInstance();
        dvService = DichVuService.getInstance();
        dvService.setDichVuDatabaseService(dvDatabaseService);
        dvService.loadAllDichVuFromDatabase();
        dvBusinessService = DichVuBusinessService.getInstance();
    }

    private void KhachHang() {
        khachHangDatabaseService = KhachHangSQLServerService.getInstance();
        khachHangService = KhachHangService.getInstance();
        khachHangService.setKhachHangDatabaseService(khachHangDatabaseService);
        khachHangService.loadAllKhachHangFromDatabase();
        khachHangBusinessService = KhachHangBusinessService.getInstance();

    }

    private void NhanVien() {
        nhanVienDatabaseService = databaseservice.NhanVienSQLServerService.getInstance();
        nhanVienService = service.NhanVienService.getInstance();
        nhanVienService.setDatabaseService(nhanVienDatabaseService);
        nhanVienService.loadAllNhanViensFromDatabase();
        nhanVienBusinessService = NhanVienBusinessService.getInstance();
    }
    
    private void HoaDon() {
        hoaDonDatabaseService = databaseservice.HoaDonSQLServerService.getInstance();
        hoaDonServiceInstance = service.HoaDonService.getInstance();
        hoaDonServiceInstance.setHoaDonDatabaseService(hoaDonDatabaseService);

        hoaDonBusinessService = businessservice.HoaDonBusinessService.getInstance();
    }

    public List<String> getAllRoomIds() {
        List<Room> rooms = getAllRooms();
        List<String> maPhongList = new ArrayList<>();
        for (Room r : rooms) {
            maPhongList.add(r.getMaPhong());
        }
        return maPhongList;
    }

    private List<Room> getAllRooms() {
        throw new UnsupportedOperationException("Chưa có phòng khả dụng.");
    }

    public List<String> getAllDichVuIds() {
        List<DichVu> dichVus = getAllDichVus();
        List<String> maDVList = new ArrayList<>();
        for (DichVu dv : dichVus) {
            maDVList.add(dv.getMaDV());
        }
        return maDVList;
    }

    private List<DichVu> getAllDichVus() {
        throw new UnsupportedOperationException("Chưa có dịch vụ khả dụng.");
    }
}

package com.mycompany.hotelmanagement;

public class BHException extends Exception{

    public BHException(String message) {
        super(message);
    }

}

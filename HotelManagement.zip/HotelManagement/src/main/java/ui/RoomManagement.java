package ui;

import businessservice.IRoomBusinessService;
import dto.RoomDto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.Pattern;

public class RoomManagement extends JPanel {
    private JTable roomTable;
    private DefaultTableModel tableModel;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi, btnTimKiem;
    private IRoomBusinessService roomBusinessService;
    private JTextField txtTimKiem;
    private JComboBox<String> cmbTieuChiTimKiem;
    private TableRowSorter<DefaultTableModel> sorter;

    public RoomManagement() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- Panel Tìm kiếm ---
        JPanel topPanel = new JPanel(new BorderLayout(5,5));
        JPanel searchControlsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        cmbTieuChiTimKiem = new JComboBox<>(new String[]{"Theo Tên Phòng", "Theo Mã Phòng", "Theo Tình Trạng"});
        searchControlsPanel.add(new JLabel("Tìm kiếm:"));
        searchControlsPanel.add(cmbTieuChiTimKiem);
        
        txtTimKiem = new JTextField(20);
        searchControlsPanel.add(txtTimKiem);
        
        btnTimKiem = new JButton("Tìm");
        searchControlsPanel.add(btnTimKiem);
        
        topPanel.add(searchControlsPanel, BorderLayout.WEST);

        btnLamMoi = new JButton("Làm mới DS");
        JPanel refreshPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        refreshPanel.add(btnLamMoi);
        topPanel.add(refreshPanel, BorderLayout.EAST);
        
        add(topPanel, BorderLayout.NORTH);

        // --- Bảng hiển thị phòng ---
        tableModel = new DefaultTableModel(new Object[]{"Mã phòng", "Tên phòng", "Tình trạng", "Giá phòng"}, 0){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Không cho sửa trực tiếp trên bảng
            }
        };
        roomTable = new JTable(tableModel);
        sorter = new TableRowSorter<>(tableModel);
        roomTable.setRowSorter(sorter);
        add(new JScrollPane(roomTable), BorderLayout.CENTER);

        // --- Panel chứa nút chức năng ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        btnThem = new JButton("Thêm Phòng");
        btnSua = new JButton("Sửa Phòng");
        btnXoa = new JButton("Xóa Phòng");

        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        add(buttonPanel, BorderLayout.SOUTH);

        // --- Gán sự kiện nút ---
        btnThem.addActionListener(e -> moFormThemSua(null));
        btnSua.addActionListener(e -> {
            int selectedViewRow = roomTable.getSelectedRow();
            if (selectedViewRow >= 0) {
                int modelRow = roomTable.convertRowIndexToModel(selectedViewRow);
                String maPhong = tableModel.getValueAt(modelRow, 0).toString();
                 RoomDto roomToEdit = roomBusinessService.getAllRooms().stream()
                                        .filter(r -> r.getMaPhong().equals(maPhong))
                                        .findFirst().orElse(null);
                if (roomToEdit != null) {
                    moFormThemSua(roomToEdit);
                } else {
                    JOptionPane.showMessageDialog(this, "Không tìm thấy thông tin phòng để sửa.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng để sửa.");
            }
        });
        btnXoa.addActionListener(e -> xoaPhong());
        btnLamMoi.addActionListener(e -> {
            txtTimKiem.setText("");
            sorter.setRowFilter(null);
            loadRoomsFromDB();
            JOptionPane.showMessageDialog(this, "Danh sách phòng đã được làm mới.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        });
        btnTimKiem.addActionListener(e -> timKiemPhong());
        txtTimKiem.addActionListener(e -> timKiemPhong());

        // Sự kiện click đúp để sửa
        roomTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && roomTable.getSelectedRow() != -1) {
                    int selectedViewRow = roomTable.getSelectedRow();
                    int modelRow = roomTable.convertRowIndexToModel(selectedViewRow);
                    String maPhong = tableModel.getValueAt(modelRow, 0).toString();
                     RoomDto roomToEdit = roomBusinessService.getAllRooms().stream()
                                        .filter(r -> r.getMaPhong().equals(maPhong))
                                        .findFirst().orElse(null);
                    if (roomToEdit != null) {
                        moFormThemSua(roomToEdit);
                    }
                }
            }
        });
    }

    public void setRoomBusinessService(IRoomBusinessService roomBusinessService) {
        this.roomBusinessService = roomBusinessService;
        if (this.roomBusinessService != null) {
            loadRoomsFromDB();
        }
    }

    private void loadRoomsFromDB() {
        if (roomBusinessService == null) {
            System.err.println("RoomBusinessService rỗng)");
            return;
        }
        tableModel.setRowCount(0);
        var roomList = roomBusinessService.getAllRooms();
        if (roomList != null) {
            for (var room : roomList) {
                tableModel.addRow(new Object[]{
                    room.getMaPhong(),
                    room.getTenPhong(),
                    room.getTinhTrang(),
                    String.format("%,.0f", room.getGiaPhong())
                });
            }
        }
    }
    
    private void timKiemPhong() {
        String tuKhoa = txtTimKiem.getText().trim();
        String tieuChi = cmbTieuChiTimKiem.getSelectedItem().toString();

        if (tuKhoa.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            try {
                RowFilter<DefaultTableModel, Object> rf = null;
                int columnIndex = -1;

                if (tieuChi.equals("Theo Tên Phòng")) {
                    columnIndex = 1; // Cột Tên phòng
                } else if (tieuChi.equals("Theo Mã Phòng")) {
                    columnIndex = 0; // Cột Mã phòng
                } else if (tieuChi.equals("Theo Tình Trạng")) {
                    columnIndex = 2; // Cột Tình Trạng
                }

                if (columnIndex != -1) {
                    rf = RowFilter.regexFilter("(?i)" + Pattern.quote(tuKhoa), columnIndex);
                }
                sorter.setRowFilter(rf);
            } catch (java.util.regex.PatternSyntaxException e) {
                JOptionPane.showMessageDialog(this, "Lỗi cú pháp biểu thức tìm kiếm.", "Lỗi tìm kiếm", JOptionPane.ERROR_MESSAGE);
                sorter.setRowFilter(null);
            }
        }
         if (roomTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy phòng nào phù hợp.", "Kết quả tìm kiếm", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void moFormThemSua(RoomDto roomDto) {
        boolean isEditMode = (roomDto != null);
        String dialogTitle = isEditMode ? "Sửa Thông Tin Phòng" : "Thêm Phòng Mới";

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), dialogTitle, true);
        dialog.setSize(450, 300);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtMa = new JTextField(20);
        JTextField txtTen = new JTextField(20);
        JComboBox<String> cbTinhTrang = new JComboBox<>(new String[]{"Trống", "Đã đặt", "Đang sửa", "Đang dọn dẹp"});
        JTextField txtGia = new JTextField(20);
        JButton btnLuu = new JButton(isEditMode ? "Cập nhật" : "Thêm");

        if (isEditMode) {
            txtMa.setText(roomDto.getMaPhong());
            txtMa.setEditable(false);
            txtTen.setText(roomDto.getTenPhong());
            cbTinhTrang.setSelectedItem(roomDto.getTinhTrang());
            txtGia.setText(String.valueOf(roomDto.getGiaPhong()));
        }

        int y = 0;
        gbc.gridx = 0; gbc.gridy = y; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(new JLabel("Mã phòng (*):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0; dialog.add(txtMa, gbc); gbc.weightx = 0;

        y++; gbc.gridx = 0; gbc.gridy = y;
        dialog.add(new JLabel("Tên phòng (*):"), gbc);
        gbc.gridx = 1; dialog.add(txtTen, gbc);

        y++; gbc.gridx = 0; gbc.gridy = y;
        dialog.add(new JLabel("Tình trạng:"), gbc);
        gbc.gridx = 1; dialog.add(cbTinhTrang, gbc);

        y++; gbc.gridx = 0; gbc.gridy = y;
        dialog.add(new JLabel("Giá phòng (*):"), gbc);
        gbc.gridx = 1; dialog.add(txtGia, gbc);

        y++; gbc.gridx = 0; gbc.gridy = y; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        dialog.add(btnLuu, gbc);

        btnLuu.addActionListener(e -> {
            String ma = txtMa.getText().trim();
            String ten = txtTen.getText().trim();
            String tinhTrang = cbTinhTrang.getSelectedItem().toString();
            String giaStr = txtGia.getText().trim();

            if (ma.isEmpty() || ten.isEmpty() || giaStr.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Mã phòng, tên phòng và giá phòng không được để trống.", "Lỗi nhập liệu", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                double gia = Double.parseDouble(giaStr);
                if (gia < 0) {
                    JOptionPane.showMessageDialog(dialog, "Giá phòng phải là số không âm.", "Lỗi nhập liệu", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                RoomDto newRoomDto = new RoomDto(ma, ten, tinhTrang, gia);
                boolean success;

                if (isEditMode) {
                    success = roomBusinessService.updateRoom(newRoomDto);
                } else {
                    RoomDto existingRoom = roomBusinessService.getAllRooms().stream()
                                           .filter(r -> r.getMaPhong().equalsIgnoreCase(ma))
                                           .findFirst().orElse(null);
                    if (existingRoom != null) {
                        JOptionPane.showMessageDialog(dialog, "Mã phòng đã tồn tại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    success = roomBusinessService.addRoom(newRoomDto);
                }

                if (success) {
                    loadRoomsFromDB(); 
                    dialog.dispose();
                    JOptionPane.showMessageDialog(this, (isEditMode ? "Cập nhật" : "Thêm") + " phòng thành công.");
                } else {
                    JOptionPane.showMessageDialog(dialog, (isEditMode ? "Cập nhật" : "Thêm") + " phòng thất bại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Giá phòng phải là một số hợp lệ.", "Lỗi định dạng", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                 JOptionPane.showMessageDialog(dialog, "Đã xảy ra lỗi: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
                 ex.printStackTrace();
            }
        });

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
    
    private void xoaPhong() {
        int selectedViewRow = roomTable.getSelectedRow();
        if (selectedViewRow >= 0) {
            int modelRow = roomTable.convertRowIndexToModel(selectedViewRow);
            String maPhong = tableModel.getValueAt(modelRow, 0).toString();
            
            int confirm = JOptionPane.showConfirmDialog(this, 
                    "Bạn có chắc chắn muốn xoá phòng " + maPhong + "?\nThao tác này không thể hoàn tác.", 
                    "Xác nhận xoá", 
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);
            
            if (confirm == JOptionPane.YES_OPTION) {
                boolean isDeleted = roomBusinessService.deleteRoom(maPhong);
                if (isDeleted) {
                    loadRoomsFromDB();
                    JOptionPane.showMessageDialog(this, "Xoá phòng thành công.");
                } else {
                    JOptionPane.showMessageDialog(this, "Không thể xoá phòng.\nPhòng có thể đang được sử dụng hoặc có liên kết dữ liệu.", "Lỗi Xóa", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn phòng để xoá.");
        }
    }
}
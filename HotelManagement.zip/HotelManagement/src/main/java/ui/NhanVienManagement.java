package ui;

import businessservice.INhanVienBusinessService;
import dto.NhanVienDto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.regex.Pattern;

public class NhanVienManagement extends JPanel {
    private JTable nvTable;
    private DefaultTableModel tableModel;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi, btnTimKiem;
    private INhanVienBusinessService nhanVienBusinessService;
    private JTextField txtTimKiem;
    private JComboBox<String> cmbTieuChiTimKiem;
    private TableRowSorter<DefaultTableModel> sorter;

    public NhanVienManagement() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- Panel Tìm kiếm ---
        JPanel topPanel = new JPanel(new BorderLayout(5,5));
        JPanel searchControlsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        cmbTieuChiTimKiem = new JComboBox<>(new String[]{"Theo Tên NV", "Theo Mã NV", "Theo Chức Vụ"});
        searchControlsPanel.add(new JLabel("Tìm kiếm:"));
        searchControlsPanel.add(cmbTieuChiTimKiem);

        txtTimKiem = new JTextField(20);
        searchControlsPanel.add(txtTimKiem);

        btnTimKiem = new JButton("Tìm");
        searchControlsPanel.add(btnTimKiem);

        topPanel.add(searchControlsPanel, BorderLayout.WEST);

        btnLamMoi = new JButton("Làm mới DS");
        JPanel refreshPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        refreshPanel.add(btnLamMoi);
        topPanel.add(refreshPanel, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);

        // --- Bảng hiển thị nhân viên ---
        tableModel = new DefaultTableModel(new Object[]{"Mã NV", "Tên NV", "Chức vụ"}, 0){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        nvTable = new JTable(tableModel);
        sorter = new TableRowSorter<>(tableModel);
        nvTable.setRowSorter(sorter);
        add(new JScrollPane(nvTable), BorderLayout.CENTER);

        // --- Panel chứa nút chức năng ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        btnThem = new JButton("Thêm Nhân Viên");
        btnSua = new JButton("Sửa Nhân Viên");
        btnXoa = new JButton("Xóa Nhân Viên");

        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        add(buttonPanel, BorderLayout.SOUTH);

        // --- Gán sự kiện nút ---
        btnThem.addActionListener(e -> moFormThemSua(null));
        btnSua.addActionListener(e -> {
            int selectedViewRow = nvTable.getSelectedRow();
            if (selectedViewRow >= 0) {
                int modelRow = nvTable.convertRowIndexToModel(selectedViewRow);
                String maNV = tableModel.getValueAt(modelRow, 0).toString();
                NhanVienDto nvToEdit = nhanVienBusinessService.getAllNhanViens().stream()
                                    .filter(nv -> nv.getMaNV().equals(maNV))
                                    .findFirst().orElse(null);
                if (nvToEdit != null) {
                    moFormThemSua(nvToEdit);
                } else {
                    JOptionPane.showMessageDialog(this, "Không tìm thấy thông tin nhân viên để sửa.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên để sửa.");
            }
        });
        btnXoa.addActionListener(e -> xoaNhanVien());
        btnLamMoi.addActionListener(e -> {
            txtTimKiem.setText("");
            sorter.setRowFilter(null);
            loadNhanViensFromDB();
            JOptionPane.showMessageDialog(this, "Danh sách nhân viên đã được làm mới.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        });
        btnTimKiem.addActionListener(e -> timKiemNhanVien());
        txtTimKiem.addActionListener(e -> timKiemNhanVien());

        nvTable.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && nvTable.getSelectedRow() != -1) {
                    int selectedViewRow = nvTable.getSelectedRow();
                    int modelRow = nvTable.convertRowIndexToModel(selectedViewRow);
                    String maNV = tableModel.getValueAt(modelRow, 0).toString();
                     NhanVienDto nvToEdit = nhanVienBusinessService.getAllNhanViens().stream()
                                    .filter(nv -> nv.getMaNV().equals(maNV))
                                    .findFirst().orElse(null);
                    if (nvToEdit != null) {
                        moFormThemSua(nvToEdit);
                    }
                }
            }
        });
    }

    public void setNhanVienBusinessService(INhanVienBusinessService service) {
        this.nhanVienBusinessService = service;
        if (this.nhanVienBusinessService != null) {
            loadNhanViensFromDB();
        }
    }

    private void loadNhanViensFromDB() {
        if (nhanVienBusinessService == null) {
            System.err.println("NhanVienBusinessService rỗng");
            return;
        }
        tableModel.setRowCount(0);
        var list = nhanVienBusinessService.getAllNhanViens();
        if (list != null) {
            for (var nv : list) {
                tableModel.addRow(new Object[]{
                    nv.getMaNV(),
                    nv.getTenNV(),
                    nv.getChucVu()
                });
            }
        }
    }

    private void timKiemNhanVien() {
        String tuKhoa = txtTimKiem.getText().trim();
        String tieuChi = cmbTieuChiTimKiem.getSelectedItem().toString();

        if (tuKhoa.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            try {
                RowFilter<DefaultTableModel, Object> rf = null;
                int columnIndex = -1;

                if (tieuChi.equals("Theo Tên NV")) {
                    columnIndex = 1; // Cột Tên NV
                } else if (tieuChi.equals("Theo Mã NV")) {
                    columnIndex = 0; // Cột Mã NV
                } else if (tieuChi.equals("Theo Chức Vụ")) {
                    columnIndex = 2; // Cột Chức Vụ
                }

                if (columnIndex != -1) {
                    rf = RowFilter.regexFilter("(?i)" + Pattern.quote(tuKhoa), columnIndex);
                }
                sorter.setRowFilter(rf);
            } catch (java.util.regex.PatternSyntaxException e) {
                JOptionPane.showMessageDialog(this, "Lỗi cú pháp biểu thức tìm kiếm.", "Lỗi tìm kiếm", JOptionPane.ERROR_MESSAGE);
                sorter.setRowFilter(null);
            }
        }
         if (nvTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy nhân viên nào phù hợp.", "Kết quả tìm kiếm", JOptionPane.INFORMATION_MESSAGE);
        }
    }


    // Gộp form thêm và sửa nhân viên
    private void moFormThemSua(NhanVienDto nvDto) {
        boolean isEditMode = (nvDto != null);
        String dialogTitle = isEditMode ? "Sửa Thông Tin Nhân Viên" : "Thêm Nhân Viên Mới";

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), dialogTitle, true);
        dialog.setSize(430, 250);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtMa = new JTextField(20);
        JTextField txtTen = new JTextField(20);
        JTextField txtChucVu = new JTextField(20);
        JButton btnLuu = new JButton(isEditMode ? "Cập nhật" : "Thêm");

        if (isEditMode) {
            txtMa.setText(nvDto.getMaNV());
            txtMa.setEditable(false);
            txtTen.setText(nvDto.getTenNV());
            txtChucVu.setText(nvDto.getChucVu());
        }

        int yPos = 0;
        gbc.gridx = 0; gbc.gridy = yPos; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(new JLabel("Mã NV (*):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0; dialog.add(txtMa, gbc); gbc.weightx = 0;

        yPos++; gbc.gridx = 0; gbc.gridy = yPos;
        dialog.add(new JLabel("Tên NV (*):"), gbc);
        gbc.gridx = 1; dialog.add(txtTen, gbc);

        yPos++; gbc.gridx = 0; gbc.gridy = yPos;
        dialog.add(new JLabel("Chức vụ (*):"), gbc);
        gbc.gridx = 1; dialog.add(txtChucVu, gbc);

        yPos++; gbc.gridx = 0; gbc.gridy = yPos; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        dialog.add(btnLuu, gbc);

        btnLuu.addActionListener(e -> {
            String ma = txtMa.getText().trim();
            String ten = txtTen.getText().trim();
            String chucVu = txtChucVu.getText().trim();

            if (ma.isEmpty() || ten.isEmpty() || chucVu.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng nhập đầy đủ thông tin (Mã, Tên, Chức vụ).", "Lỗi Nhập Liệu", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                NhanVienDto newNvDto = new NhanVienDto(ma, ten, chucVu);
                boolean success;

                if (isEditMode) {
                    success = nhanVienBusinessService.updateNhanVien(newNvDto);
                } else {
                    NhanVienDto existingNV = nhanVienBusinessService.getAllNhanViens().stream()
                                           .filter(nv -> nv.getMaNV().equalsIgnoreCase(ma))
                                           .findFirst().orElse(null);
                    if (existingNV != null) {
                        JOptionPane.showMessageDialog(dialog, "Mã nhân viên đã tồn tại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    success = nhanVienBusinessService.addNhanVien(newNvDto);
                }

                if (success) {
                    loadNhanViensFromDB();
                    dialog.dispose();
                    JOptionPane.showMessageDialog(this, (isEditMode ? "Cập nhật" : "Thêm") + " nhân viên thành công.");
                } else {
                    JOptionPane.showMessageDialog(dialog, (isEditMode ? "Cập nhật" : "Thêm") + " nhân viên thất bại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                 JOptionPane.showMessageDialog(dialog, "Đã xảy ra lỗi: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
                 ex.printStackTrace();
            }
        });

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void xoaNhanVien() {
        int selectedViewRow = nvTable.getSelectedRow();
        if (selectedViewRow >= 0) {
            int modelRow = nvTable.convertRowIndexToModel(selectedViewRow);
            String maNV = tableModel.getValueAt(modelRow, 0).toString();
            String tenNV = tableModel.getValueAt(modelRow, 1).toString();

            int confirm = JOptionPane.showConfirmDialog(this,
                    "Bạn có chắc chắn muốn xoá nhân viên: " + tenNV + " (Mã: " + maNV + ")?\nThao tác này không thể hoàn tác.",
                    "Xác nhận xoá",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                boolean isDeleted = nhanVienBusinessService.deleteNhanVien(maNV);
                if (isDeleted) {
                    loadNhanViensFromDB(); // Tải lại bảng
                    JOptionPane.showMessageDialog(this, "Xoá nhân viên thành công.");
                } else {
                    JOptionPane.showMessageDialog(this, "Không thể xoá nhân viên.\nNhân viên có thể đang được tham chiếu trong hóa đơn hoặc các bản ghi khác.", "Lỗi Xóa", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn nhân viên để xoá.");
        }
    }
}
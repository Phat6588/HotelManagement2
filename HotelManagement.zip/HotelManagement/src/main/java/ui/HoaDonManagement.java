package ui;

import businessservice.HoaDonBusinessService;
import businessservice.IHoaDonBusinessService;
import businessservice.IKhachHangBusinessService;
import businessservice.INhanVienBusinessService;
import businessservice.IDichVuBusinessService;
import businessservice.IRoomBusinessService;
import dto.ChiTietHoaDon_DichVuDto;
import dto.DichVuDto;
import dto.HoaDonDto;
import dto.KhachHangDto;
import dto.NhanVienDto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.regex.Pattern;

public class HoaDonManagement extends JPanel {
    private IHoaDonBusinessService hoaDonBusinessService;
    private IKhachHangBusinessService khachHangBusinessService;
    private INhanVienBusinessService nhanVienBusinessService;
    private IDichVuBusinessService dichVuBusinessService;
    private IRoomBusinessService roomBusinessService;

    private JTable tblHoaDon;
    private DefaultTableModel tableModelHoaDon;
    private JButton btnThemHoaDon, btnXemChiTiet, btnLamMoiHoaDon, btnTimKiemHD;
    private JTextField txtTimKiemHD;
    private JComboBox<String> cmbTieuChiTimKiemHD;
    private TableRowSorter<DefaultTableModel> sorterHoaDon;

    private List<ChiTietHoaDon_DichVuDto> currentChiTietListInForm;


    public HoaDonManagement() {
        this.hoaDonBusinessService = HoaDonBusinessService.getInstance();
        this.currentChiTietListInForm = new ArrayList<>();
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- Panel Tìm kiếm Hóa Đơn ---
        JPanel topControlPanel = new JPanel(new BorderLayout(5,5));
        JPanel searchControlsPanelHD = new JPanel(new FlowLayout(FlowLayout.LEFT));

        cmbTieuChiTimKiemHD = new JComboBox<>(new String[]{
                "Theo Tên KH", "Theo Mã NV", "Theo Ngày Lập (dd/MM/yyyy)"
        });
        searchControlsPanelHD.add(new JLabel("Tìm HĐ:"));
        searchControlsPanelHD.add(cmbTieuChiTimKiemHD);

        txtTimKiemHD = new JTextField(15); // Kích thước ô tìm kiếm
        searchControlsPanelHD.add(txtTimKiemHD);

        btnTimKiemHD = new JButton("Tìm HĐ");
        searchControlsPanelHD.add(btnTimKiemHD);

        topControlPanel.add(searchControlsPanelHD, BorderLayout.WEST);

        btnLamMoiHoaDon = new JButton("Làm mới DS HĐ");
        JPanel refreshPanelHD = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        refreshPanelHD.add(btnLamMoiHoaDon);
        topControlPanel.add(refreshPanelHD, BorderLayout.EAST);

        add(topControlPanel, BorderLayout.NORTH);

        // --- Bảng Hóa Đơn ---
        String[] columns = {"Mã HĐ", "Khách Hàng", "Nhân Viên", "Ngày Lập", "Tổng Cộng", "Ghi Chú"};
        tableModelHoaDon = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblHoaDon = new JTable(tableModelHoaDon);
        sorterHoaDon = new TableRowSorter<>(tableModelHoaDon);
        tblHoaDon.setRowSorter(sorterHoaDon);
        add(new JScrollPane(tblHoaDon), BorderLayout.CENTER);

        // --- Panel Nút Chức Năng ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        btnThemHoaDon = new JButton("Tạo Hóa Đơn Mới");
        btnXemChiTiet = new JButton("Xem Chi Tiết HĐ");
        buttonPanel.add(btnThemHoaDon);
        buttonPanel.add(btnXemChiTiet);
        add(buttonPanel, BorderLayout.SOUTH);

        btnThemHoaDon.addActionListener(e -> moFormTaoHoaDon());
        btnXemChiTiet.addActionListener(e -> {
            int selectedViewRow = tblHoaDon.getSelectedRow();
            if (selectedViewRow >= 0) {
                int modelRow = tblHoaDon.convertRowIndexToModel(selectedViewRow);
                String maHD = tableModelHoaDon.getValueAt(modelRow, 0).toString();
                moFormXemChiTiet(maHD);
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn một hóa đơn để xem chi tiết.", "Thông báo", JOptionPane.WARNING_MESSAGE);
            }
        });

        btnLamMoiHoaDon.addActionListener(e -> {
            txtTimKiemHD.setText("");
            cmbTieuChiTimKiemHD.setSelectedIndex(0);
            sorterHoaDon.setRowFilter(null); // Xóa bộ lọc
            loadHoaDonData();
            JOptionPane.showMessageDialog(this, "Danh sách hóa đơn đã được làm mới.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        });
        btnTimKiemHD.addActionListener(e -> timKiemHoaDon());
        txtTimKiemHD.addActionListener(e -> timKiemHoaDon());

        tblHoaDon.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tblHoaDon.getSelectedRow() != -1) {
                    int modelRow = tblHoaDon.convertRowIndexToModel(tblHoaDon.getSelectedRow());
                    String maHD = tableModelHoaDon.getValueAt(modelRow, 0).toString();
                     moFormXemChiTiet(maHD);
                }
            }
        });
    }

    public void initServices(IKhachHangBusinessService khachHangBS, INhanVienBusinessService nhanVienBS, IDichVuBusinessService dichVuBS, IRoomBusinessService roomBS) {
        this.khachHangBusinessService = khachHangBS;
        this.nhanVienBusinessService = nhanVienBS;
        this.dichVuBusinessService = dichVuBS;
        this.roomBusinessService = roomBS;
        if (this.hoaDonBusinessService != null) {
            loadHoaDonData();
        }
    }

    public void loadHoaDonData() {
        if (hoaDonBusinessService == null) {
            System.err.println("HoaDonService rỗng");
            return;
        }
        List<HoaDonDto> list = hoaDonBusinessService.getAllHoaDon();
        tableModelHoaDon.setRowCount(0);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        if (list != null) {
            for (HoaDonDto dto : list) {
                tableModelHoaDon.addRow(new Object[]{
                        dto.getMaHD(),
                        dto.getTenKH() != null ? dto.getTenKH() : dto.getMaKH(),
                        dto.getTenNV() != null ? dto.getTenNV() : dto.getMaNV(),
                        dto.getNgayLapHD().format(formatter),
                        String.format("%,.0f VND", dto.getTongCong()),
                        dto.getGhiChu()
                });
            }
        }
    }

    private void timKiemHoaDon() {
        String tuKhoa = txtTimKiemHD.getText().trim();
        String tieuChi = cmbTieuChiTimKiemHD.getSelectedItem().toString();


        if (sorterHoaDon == null) {
            System.err.println("sorterHoaDon rỗng");
            return;
        }
         if (hoaDonBusinessService == null) {
            System.err.println("hoaDonBusinessService rỗng");
            return;
        }


        if (tuKhoa.isEmpty()) {
            sorterHoaDon.setRowFilter(null);
        } else {
            try {
                RowFilter<DefaultTableModel, Object> rf = null;
                int columnIndex = -1;

                if (tieuChi.equals("Theo Tên KH")) {
                    columnIndex = 1; // Cột Khách Hàng (hiển thị tên)
                    rf = RowFilter.regexFilter("(?i)" + Pattern.quote(tuKhoa), columnIndex);
                }
                else if (tieuChi.equals("Theo Tên NV")) {
                    columnIndex = 2; // Cột Nhân Viên (hiển thị tên)
                    rf = RowFilter.regexFilter("(?i)" + Pattern.quote(tuKhoa), columnIndex);
                } else if (tieuChi.equals("Theo Ngày Lập (dd/MM/yyyy)")) {
                    columnIndex = 3; // Cột Ngày Lập
                    try {
                        rf = RowFilter.regexFilter("^" + Pattern.quote(tuKhoa) + "$", columnIndex);
                    } catch (Exception exDate) {
                        JOptionPane.showMessageDialog(this, "Định dạng ngày tìm kiếm không hợp lệ (dd/MM/yyyy) hoặc lỗi khi lọc ngày.", "Lỗi Định Dạng Ngày", JOptionPane.ERROR_MESSAGE);
                        sorterHoaDon.setRowFilter(null);
                        return;
                    }
                }

                if (rf != null) {
                     sorterHoaDon.setRowFilter(rf);
                }

            } catch (java.util.regex.PatternSyntaxException e) {
                JOptionPane.showMessageDialog(this, "Lỗi cú pháp trong từ khóa tìm kiếm.", "Lỗi tìm kiếm", JOptionPane.ERROR_MESSAGE);
                sorterHoaDon.setRowFilter(null);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi không xác định khi tìm kiếm: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
                sorterHoaDon.setRowFilter(null);
                ex.printStackTrace();
            }
        }

        if (tblHoaDon.getRowCount() == 0 && !tuKhoa.isEmpty() &&
            !(tieuChi.equals("Theo Mã KH") || tieuChi.equals("Theo Mã NV")) ) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy hóa đơn nào phù hợp.", "Kết quả tìm kiếm", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void moFormTaoHoaDon() {
        if (khachHangBusinessService == null || nhanVienBusinessService == null || roomBusinessService == null || dichVuBusinessService == null) {
            JOptionPane.showMessageDialog(this, "Đã có lỗi xảy ra.", "Lỗi Service", JOptionPane.ERROR_MESSAGE);
            return;
        }
        currentChiTietListInForm.clear();

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Tạo Hóa Đơn Mới", true);
        dialog.setSize(750, 700);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.getRootPane().setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));


        JPanel mainPanel = new JPanel(new BorderLayout(10,10));

        // Panel Thông tin chung
        JPanel thongTinChungPanel = new JPanel(new GridBagLayout());
        thongTinChungPanel.setBorder(BorderFactory.createTitledBorder("Thông tin chung hóa đơn"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST; gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;


        JTextField txtMaHD = new JTextField(hoaDonBusinessService.taoMaHoaDonMoi(), 20);
        txtMaHD.setEditable(false);
        JComboBox<KhachHangDto> cmbKhachHang = new JComboBox<>(new Vector<>(khachHangBusinessService.getAllKhachHang()));
        JComboBox<NhanVienDto> cmbNhanVien = new JComboBox<>(new Vector<>(nhanVienBusinessService.getAllNhanViens()));
        JTextField txtNgayLapHD = new JTextField(LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")), 20);

        JTextField txtTienPhong = new JTextField("0", 15);
        txtTienPhong.setEditable(false);
        txtTienPhong.setHorizontalAlignment(JTextField.RIGHT);

        cmbKhachHang.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof KhachHangDto) {
                    setText(((KhachHangDto) value).getMaKH() + " - " + ((KhachHangDto) value).getTenKH());
                } else if (value == null && index == -1){
                     setText("--- Chọn khách hàng ---");
                }
                return this;
            }
        });
        cmbKhachHang.setSelectedIndex(-1);

         cmbNhanVien.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof NhanVienDto) {
                    setText(((NhanVienDto) value).getMaNV() + " - " + ((NhanVienDto) value).getTenNV());
                } else if (value == null && index == -1){
                     setText("--- Chọn nhân viên ---");
                }
                return this;
            }
        });
        cmbNhanVien.setSelectedIndex(-1);

        gbc.gridwidth = 1;
        thongTinChungPanel.add(new JLabel("Mã HĐ:"), gbc);
        gbc.gridx++; gbc.weightx = 1.0; thongTinChungPanel.add(txtMaHD, gbc); gbc.weightx = 0;

        gbc.gridx = 0; gbc.gridy++; thongTinChungPanel.add(new JLabel("Khách Hàng:"), gbc);
        gbc.gridx++; gbc.weightx = 1.0; thongTinChungPanel.add(cmbKhachHang, gbc); gbc.weightx = 0;

        gbc.gridx = 0; gbc.gridy++; thongTinChungPanel.add(new JLabel("Nhân Viên Lập:"), gbc);
        gbc.gridx++; gbc.weightx = 1.0; thongTinChungPanel.add(cmbNhanVien, gbc); gbc.weightx = 0;

        gbc.gridx = 0; gbc.gridy++; thongTinChungPanel.add(new JLabel("Ngày Lập (dd/MM/yyyy):"), gbc);
        gbc.gridx++; gbc.weightx = 1.0; thongTinChungPanel.add(txtNgayLapHD, gbc); gbc.weightx = 0;
        
        gbc.gridx = 0; gbc.gridy++; thongTinChungPanel.add(new JLabel("Tiền Phòng (VND):"), gbc);
        gbc.gridx++; gbc.weightx = 1.0; thongTinChungPanel.add(txtTienPhong, gbc); gbc.weightx = 0;
        mainPanel.add(thongTinChungPanel, BorderLayout.NORTH);

        JPanel dichVuPanel = new JPanel(new GridBagLayout());
        dichVuPanel.setBorder(BorderFactory.createTitledBorder("Chi tiết dịch vụ sử dụng"));
        GridBagConstraints gbcDV = new GridBagConstraints();
        gbcDV.insets = new Insets(5, 5, 5, 5);


        JPanel themDichVuControlPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        JComboBox<DichVuDto> cmbDichVu = new JComboBox<>(new Vector<>(dichVuBusinessService.getAllDichVus()));
        cmbDichVu.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof DichVuDto) {
                    setText(((DichVuDto) value).getTenDV() + " (" + String.format("%,.0f", ((DichVuDto) value).getDonGia()) + " VND)");
                } else if (value == null && index == -1) {
                    setText("--- Chọn dịch vụ ---");
                }
                return this;
            }
        });
        cmbDichVu.setSelectedIndex(-1);
        JSpinner spnSoLuongDV = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        ((JSpinner.DefaultEditor) spnSoLuongDV.getEditor()).getTextField().setColumns(3);
        JButton btnThemDV = new JButton("Thêm DV");
        JButton btnXoaDV = new JButton("Xóa DV");

        themDichVuControlPanel.add(new JLabel("Dịch vụ:"));
        themDichVuControlPanel.add(cmbDichVu);
        themDichVuControlPanel.add(new JLabel("Số lượng:"));
        themDichVuControlPanel.add(spnSoLuongDV);
        themDichVuControlPanel.add(btnThemDV);
        themDichVuControlPanel.add(btnXoaDV);

        gbcDV.gridx = 0; gbcDV.gridy = 0; gbcDV.weightx = 1.0;
        gbcDV.fill = GridBagConstraints.HORIZONTAL;
        gbcDV.anchor = GridBagConstraints.NORTHWEST;
        dichVuPanel.add(themDichVuControlPanel, gbcDV);


        DefaultTableModel chiTietDVTableModel = new DefaultTableModel(new String[]{"Mã DV", "Tên DV", "SL", "Đơn Giá", "Thành Tiền"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        JTable tblChiTietDV = new JTable(chiTietDVTableModel);
        JScrollPane scrollPaneChiTietDV = new JScrollPane(tblChiTietDV);
        scrollPaneChiTietDV.setPreferredSize(new Dimension(680, 200));

        gbcDV.gridy = 1;
        gbcDV.weighty = 1.0;
        gbcDV.fill = GridBagConstraints.BOTH;
        dichVuPanel.add(scrollPaneChiTietDV, gbcDV);
        mainPanel.add(dichVuPanel, BorderLayout.CENTER);

        JPanel summaryPanel = new JPanel(new GridBagLayout());
        summaryPanel.setBorder(BorderFactory.createTitledBorder("Tổng kết hóa đơn"));
        GridBagConstraints gbcSummary = new GridBagConstraints();
        gbcSummary.gridx = 0; gbcSummary.gridy = 0; gbcSummary.anchor = GridBagConstraints.EAST; gbcSummary.insets = new Insets(5,5,5,5);
        
        JTextField txtTienDichVu = new JTextField("0", 15);
        txtTienDichVu.setEditable(false);
        txtTienDichVu.setHorizontalAlignment(JTextField.RIGHT);
        JTextField txtTongCong = new JTextField("0", 15);
        txtTongCong.setEditable(false);
        txtTongCong.setHorizontalAlignment(JTextField.RIGHT);
        txtTongCong.setFont(txtTongCong.getFont().deriveFont(Font.BOLD));
        JTextArea txtGhiChu = new JTextArea(3, 20);
        JScrollPane scrollGhiChu = new JScrollPane(txtGhiChu);


        summaryPanel.add(new JLabel("Tổng Tiền Dịch Vụ (VND):"), gbcSummary);
        gbcSummary.gridx++; gbcSummary.weightx = 1.0; gbcSummary.fill = GridBagConstraints.HORIZONTAL;
        summaryPanel.add(txtTienDichVu, gbcSummary); gbcSummary.weightx = 0; gbcSummary.fill = GridBagConstraints.NONE;

        gbcSummary.gridx = 0; gbcSummary.gridy++; gbcSummary.anchor = GridBagConstraints.EAST;
        summaryPanel.add(new JLabel("TỔNG CỘNG (VND):"), gbcSummary);
        gbcSummary.gridx++; gbcSummary.weightx = 1.0; gbcSummary.fill = GridBagConstraints.HORIZONTAL;
        summaryPanel.add(txtTongCong, gbcSummary); gbcSummary.weightx = 0; gbcSummary.fill = GridBagConstraints.NONE;

        gbcSummary.gridx = 0; gbcSummary.gridy++; gbcSummary.anchor = GridBagConstraints.NORTHEAST;
        summaryPanel.add(new JLabel("Ghi Chú:"), gbcSummary);
        gbcSummary.gridx++; gbcSummary.weightx = 1.0; gbcSummary.weighty = 1.0;
        gbcSummary.fill = GridBagConstraints.BOTH;
        summaryPanel.add(scrollGhiChu, gbcSummary);

        mainPanel.add(summaryPanel, BorderLayout.SOUTH);
        dialog.add(mainPanel, BorderLayout.CENTER);
        
        cmbKhachHang.addActionListener((ActionEvent e) -> {
            KhachHangDto selectedKH = (KhachHangDto) cmbKhachHang.getSelectedItem();
            if (selectedKH != null) {
                double tienPhong = 0.0;
                txtTienPhong.setText(String.format("%,.0f", tienPhong));
                currentChiTietListInForm.clear();
                updateChiTietDVTable(chiTietDVTableModel, currentChiTietListInForm);
                updateTongTienFields(txtTienPhong, txtTienDichVu, txtTongCong);
            } else {
                txtTienPhong.setText("0");
                currentChiTietListInForm.clear();
                updateChiTietDVTable(chiTietDVTableModel, currentChiTietListInForm);
                updateTongTienFields(txtTienPhong, txtTienDichVu, txtTongCong);
            }
        });

        btnThemDV.addActionListener(e -> {
            DichVuDto selectedDV = (DichVuDto) cmbDichVu.getSelectedItem();
            if (selectedDV == null) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng chọn một dịch vụ.", "Thông báo", JOptionPane.WARNING_MESSAGE);
                return;
            }
            int soLuong = (Integer) spnSoLuongDV.getValue();
             if (soLuong <= 0) {
                JOptionPane.showMessageDialog(dialog, "Số lượng phải lớn hơn 0.", "Thông báo", JOptionPane.WARNING_MESSAGE);
                return;
            }

            boolean daTonTai = false;
            for(ChiTietHoaDon_DichVuDto ct : currentChiTietListInForm){
                if(ct.getDichVuDto() != null && ct.getDichVuDto().getMaDV().equals(selectedDV.getMaDV())){
                    ct.setSoLuong(ct.getSoLuong() + soLuong);
                    ct.setThanhTien(ct.getSoLuong() * ct.getDonGiaTaiThoiDiemSuDung());
                    daTonTai = true;
                    break;
                }
            }

            if(!daTonTai){
                ChiTietHoaDon_DichVuDto chiTietMoi = new ChiTietHoaDon_DichVuDto();
                chiTietMoi.setDichVuDto(selectedDV);
                chiTietMoi.setSoLuong(soLuong);
                chiTietMoi.setDonGiaTaiThoiDiemSuDung(selectedDV.getDonGia());
                chiTietMoi.setThanhTien(selectedDV.getDonGia() * soLuong);
                currentChiTietListInForm.add(chiTietMoi);
            }

            updateChiTietDVTable(chiTietDVTableModel, currentChiTietListInForm);
            updateTongTienFields(txtTienPhong, txtTienDichVu, txtTongCong);
            spnSoLuongDV.setValue(1);
            cmbDichVu.setSelectedIndex(-1);
        });

        btnXoaDV.addActionListener(e -> {
            int selectedRowInTable = tblChiTietDV.getSelectedRow();
            if (selectedRowInTable >= 0) {
                currentChiTietListInForm.remove(selectedRowInTable);
                updateChiTietDVTable(chiTietDVTableModel, currentChiTietListInForm);
                updateTongTienFields(txtTienPhong, txtTienDichVu, txtTongCong);
            } else {
                JOptionPane.showMessageDialog(dialog, "Vui lòng chọn một dịch vụ trong bảng để xóa.", "Thông báo", JOptionPane.WARNING_MESSAGE);
            }
        });

        JButton btnLuu = new JButton("Lưu Hóa Đơn");
        btnLuu.setFont(new Font("Arial", Font.BOLD, 14));
        btnLuu.addActionListener(e -> {
            try {
                String maHDValue = txtMaHD.getText().trim();
                KhachHangDto selectedKH = (KhachHangDto) cmbKhachHang.getSelectedItem();
                NhanVienDto selectedNV = (NhanVienDto) cmbNhanVien.getSelectedItem();
                LocalDate ngayLap;

                if (maHDValue.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Mã hóa đơn không được để trống.", "Lỗi", JOptionPane.ERROR_MESSAGE); return;
                }
                if (selectedKH == null) {
                    JOptionPane.showMessageDialog(dialog, "Vui lòng chọn khách hàng.", "Lỗi", JOptionPane.ERROR_MESSAGE); return;
                }
                if (selectedNV == null) {
                    JOptionPane.showMessageDialog(dialog, "Vui lòng chọn nhân viên.", "Lỗi", JOptionPane.ERROR_MESSAGE); return;
                }
                try {
                     ngayLap = LocalDate.parse(txtNgayLapHD.getText().trim(), DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                } catch (DateTimeParseException ex) {
                    JOptionPane.showMessageDialog(dialog, "Ngày lập hóa đơn không hợp lệ. Định dạng dd/MM/yyyy.", "Lỗi", JOptionPane.ERROR_MESSAGE); return;
                }

                HoaDonDto newHoaDon = new HoaDonDto();
                newHoaDon.setMaHD(maHDValue);
                newHoaDon.setKhachHangDto(selectedKH);
                newHoaDon.setNhanVienDto(selectedNV);
                newHoaDon.setNgayLapHD(ngayLap);

                double tienPhongDb = Double.parseDouble(txtTienPhong.getText().replace(",", ""));
                double tienDichVuDb = Double.parseDouble(txtTienDichVu.getText().replace(",", ""));
                newHoaDon.setTongTienPhong(tienPhongDb);
                newHoaDon.setTongTienDichVu(tienDichVuDb);
                newHoaDon.setTongCong(tienPhongDb + tienDichVuDb);
                newHoaDon.setGhiChu(txtGhiChu.getText().trim());
                
                currentChiTietListInForm.forEach(ct -> ct.setMaHD(newHoaDon.getMaHD()));
                newHoaDon.setChiTietDichVu(new ArrayList<>(currentChiTietListInForm));

                if (hoaDonBusinessService.createHoaDon(newHoaDon)) {
                    JOptionPane.showMessageDialog(dialog, "Tạo hóa đơn thành công!");
                    loadHoaDonData();
                    dialog.dispose();
                } else {
                    JOptionPane.showMessageDialog(dialog, "Tạo hóa đơn thất bại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Lỗi định dạng số tiền: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Lỗi khi lưu hóa đơn: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
        JPanel southButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        southButtonPanel.add(btnLuu);
        dialog.add(southButtonPanel, BorderLayout.SOUTH);

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void moFormXemChiTiet(String maHD) {
        HoaDonDto hoaDonDto = hoaDonBusinessService.getHoaDonById(maHD);
        if (hoaDonDto == null) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy thông tin hóa đơn.", "Lỗi", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Chi Tiết Hóa Đơn - " + maHD, true);
        dialog.setSize(650, 550);
        dialog.setLayout(new BorderLayout(10,10));
        dialog.getRootPane().setBorder(BorderFactory.createEmptyBorder(10,10,10,10));


        JTextArea txtChiTiet = new JTextArea();
        txtChiTiet.setEditable(false);
        txtChiTiet.setFont(new Font("Monospaced", Font.PLAIN, 13));
        StringBuilder sb = new StringBuilder();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        sb.append("===============================================================\n");
        sb.append(String.format("%38s\n", "CHI TIẾT HÓA ĐƠN"));
        sb.append("===============================================================\n");
        sb.append(String.format("Mã HĐ      : %-30s Ngày lập: %s\n", hoaDonDto.getMaHD(), hoaDonDto.getNgayLapHD().format(dateFormatter)));
        sb.append(String.format("Khách hàng : %s (Mã: %s)\n", hoaDonDto.getTenKH(), hoaDonDto.getMaKH()));
        sb.append(String.format("Nhân viên   : %s (Mã: %s)\n", hoaDonDto.getTenNV(), hoaDonDto.getMaNV()));
        sb.append("---------------------------------------------------------------\n");
        
        sb.append(String.format("Tiền phòng                                  : %,.0f VND\n", hoaDonDto.getTongTienPhong()));
        sb.append("---------------------------------------------------------------\n");
        sb.append("Chi tiết dịch vụ:\n");
        sb.append(String.format("%-8s | %-25.25s | %3s | %10s | %10s\n", "Mã DV", "Tên Dịch Vụ", "SL", "Đơn Giá", "Thành Tiền"));
        sb.append("---------|---------------------------|-----|------------|------------\n");
        
        List<ChiTietHoaDon_DichVuDto> chiTietList = hoaDonDto.getChiTietDichVu();

        if (chiTietList == null || chiTietList.isEmpty()) {
             sb.append("  (Không có dịch vụ nào được sử dụng)\n");
        } else {
            for (ChiTietHoaDon_DichVuDto ct : chiTietList) {
                sb.append(String.format("%-8s | %-25.25s | %3d | %,10.0f | %,10.0f\n",
                        ct.getDichVuDto() != null ? ct.getDichVuDto().getMaDV() : "N/A",
                        ct.getDichVuDto() != null ? ct.getDichVuDto().getTenDV() : "N/A",
                        ct.getSoLuong(),
                        ct.getDonGiaTaiThoiDiemSuDung(),
                        ct.getThanhTien()));
            }
        }
        sb.append("---------------------------------------------------------------\n");
        sb.append(String.format("Tổng tiền dịch vụ                         : %,.0f VND\n", hoaDonDto.getTongTienDichVu()));
        sb.append("===============================================================\n");
        sb.append(String.format("TỔNG CỘNG THANH TOÁN                      : %,.0f VND\n", hoaDonDto.getTongCong()));
        sb.append("===============================================================\n");
        sb.append("Ghi chú: \n  ").append(hoaDonDto.getGhiChu() != null && !hoaDonDto.getGhiChu().isEmpty() ? hoaDonDto.getGhiChu() : "(Không có ghi chú)").append("\n");
        sb.append("---------------------------------------------------------------\n");


        txtChiTiet.setText(sb.toString());
        dialog.add(new JScrollPane(txtChiTiet), BorderLayout.CENTER);

        JButton btnDong = new JButton("Đóng");
        btnDong.addActionListener(e -> dialog.dispose());
        JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        southPanel.add(btnDong);
        dialog.add(southPanel, BorderLayout.SOUTH);

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void updateChiTietDVTable(DefaultTableModel model, List<ChiTietHoaDon_DichVuDto> list) {
        model.setRowCount(0);
        if (list == null) return;
        for (ChiTietHoaDon_DichVuDto ct : list) {
            String tenDV = (ct.getDichVuDto() != null) ? ct.getDichVuDto().getTenDV() : "N/A";
            String maDV = (ct.getDichVuDto() != null) ? ct.getDichVuDto().getMaDV() : "N/A";
            model.addRow(new Object[]{
                maDV,
                tenDV,
                ct.getSoLuong(),
                String.format("%,.0f", ct.getDonGiaTaiThoiDiemSuDung()),
                String.format("%,.0f", ct.getThanhTien())
            });
        }
    }
    private void updateTongTienFields(JTextField txtTienPhong, JTextField txtTienDichVu, JTextField txtTongCong) {
        double tienPhong = 0;
        double tienDichVu = 0;
        try {
            String tienPhongStr = txtTienPhong.getText().replace(",", "").trim();
            if (!tienPhongStr.isEmpty()) {
                tienPhong = Double.parseDouble(tienPhongStr);
            }
        } catch (NumberFormatException ignored) {
        }

        if (hoaDonBusinessService != null) {
            tienDichVu = hoaDonBusinessService.tinhTongTienDichVu(currentChiTietListInForm);
        }

        txtTienDichVu.setText(String.format("%,.0f", tienDichVu));
        txtTongCong.setText(String.format("%,.0f", tienPhong + tienDichVu));
    }
}
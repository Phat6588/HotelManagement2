package ui;

import businessservice.IKhachHangBusinessService;
import businessservice.KhachHangBusinessService;
import dto.KhachHangDto;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.regex.Pattern;

public class UserManagement extends JPanel {

    private IKhachHangBusinessService khachHangBusinessService;
    private JTable tblKhachHang;
    private DefaultTableModel tableModel;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi, btnTimKiem;
    private JTextField txtTimKiem;
    private JComboBox<String> cmbTieuChiTimKiem;
    private TableRowSorter<DefaultTableModel> sorter;

    public UserManagement() {
        setLayout(new BorderLayout(10, 10));

        // --- Panel Tìm kiếm ---
        JPanel topPanel = new JPanel(new BorderLayout(5, 5));
        JPanel searchCriteriaPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        String[] tieuChi = {"Theo Tên KH", "Theo Mã KH", "Theo SDT"};
        cmbTieuChiTimKiem = new JComboBox<>(tieuChi);
        searchCriteriaPanel.add(new JLabel("Tìm kiếm:"));
        searchCriteriaPanel.add(cmbTieuChiTimKiem);

        txtTimKiem = new JTextField(20);
        searchCriteriaPanel.add(txtTimKiem);

        btnTimKiem = new JButton("Tìm");
        searchCriteriaPanel.add(btnTimKiem);
        
        btnLamMoi = new JButton("Làm mới DS");
        JPanel refreshPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        refreshPanel.add(btnLamMoi);

        topPanel.add(searchCriteriaPanel, BorderLayout.WEST);
        topPanel.add(refreshPanel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        // --- Bảng Khách Hàng ---
        String[] columns = {"Mã KH", "Tên KH", "CMND", "SDT", "Địa Chỉ", "Ngày Nhận", "Ngày Trả"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblKhachHang = new JTable(tableModel);
        sorter = new TableRowSorter<>(tableModel);
        tblKhachHang.setRowSorter(sorter); 
        add(new JScrollPane(tblKhachHang), BorderLayout.CENTER);

        // --- Panel Nút Chức Năng ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnThem = new JButton("Thêm Khách Hàng");
        btnSua = new JButton("Sửa Khách Hàng");
        btnXoa = new JButton("Xóa Khách Hàng");
        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        add(buttonPanel, BorderLayout.SOUTH);

        btnThem.addActionListener(e -> moFormThemSua(null));
        btnSua.addActionListener(e -> {
            int modelRow = tblKhachHang.getSelectedRow();
            if (modelRow >= 0) {
                int viewRow = tblKhachHang.convertRowIndexToModel(modelRow);
                String maKH = tableModel.getValueAt(viewRow, 0).toString();
                KhachHangDto khDtoToEdit = khachHangBusinessService.getAllKhachHang().stream()
                                            .filter(kh -> kh.getMaKH().equals(maKH))
                                            .findFirst()
                                            .orElse(null);
                if (khDtoToEdit != null) {
                    moFormThemSua(khDtoToEdit);
                } else {
                     JOptionPane.showMessageDialog(this, "Không tìm thấy thông tin khách hàng để sửa.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng để sửa.");
            }
        });
        btnXoa.addActionListener(e -> xoaKhachHang());
        btnLamMoi.addActionListener(e -> {
            txtTimKiem.setText("");
            sorter.setRowFilter(null);
            loadKhachHangData();
            JOptionPane.showMessageDialog(this, "Dữ liệu đã được làm mới!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        });
        btnTimKiem.addActionListener(e -> timKiemKhachHang());
        txtTimKiem.addActionListener(e -> timKiemKhachHang());

        tblKhachHang.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tblKhachHang.getSelectedRow() != -1) {
                    int modelRow = tblKhachHang.convertRowIndexToModel(tblKhachHang.getSelectedRow());
                    String maKH = tableModel.getValueAt(modelRow, 0).toString();
                     KhachHangDto khDtoToEdit = khachHangBusinessService.getAllKhachHang().stream()
                                            .filter(kh -> kh.getMaKH().equals(maKH))
                                            .findFirst()
                                            .orElse(null);
                    if (khDtoToEdit != null) {
                         moFormThemSua(khDtoToEdit);
                    }
                }
            }
        });
    }

    public void setKhachHangBusinessService(IKhachHangBusinessService service) {
        this.khachHangBusinessService = service;
        if (this.khachHangBusinessService != null) {
            loadKhachHangData();
        }
    }

    private void loadKhachHangData() {
        if (khachHangBusinessService == null) {
            System.err.println("KhachHangBusinessService is null in UserManagement.loadKhachHangData()");
            return;
        }
        List<KhachHangDto> list = khachHangBusinessService.getAllKhachHang();
        tableModel.setRowCount(0);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        if (list != null) {
            for (KhachHangDto dto : list) {
                Vector<Object> row = new Vector<>();
                row.add(dto.getMaKH());
                row.add(dto.getTenKH());
                row.add(dto.getCmnd());
                row.add(dto.getSdt());
                row.add(dto.getDiaChi());
                row.add(dto.getNgayNhan() != null ? dto.getNgayNhan().format(formatter) : "");
                row.add(dto.getNgayTra() != null ? dto.getNgayTra().format(formatter) : "");
                tableModel.addRow(row);
            }
        }
    }

    private void timKiemKhachHang() {
        String tuKhoa = txtTimKiem.getText().trim();
        String tieuChi = cmbTieuChiTimKiem.getSelectedItem().toString();

        if (tuKhoa.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            try {
                RowFilter<DefaultTableModel, Object> rf = null;
                int columnIndex = -1;
                if (tieuChi.equals("Theo Tên KH")) {
                    columnIndex = 1; // Cột Tên KH
                } else if (tieuChi.equals("Theo Mã KH")) {
                    columnIndex = 0; // Cột Mã KH
                } else if (tieuChi.equals("Theo SDT")) {
                    columnIndex = 3; // Cột SDT
                }

                if (columnIndex != -1) {
                    rf = RowFilter.regexFilter("(?i)" + Pattern.quote(tuKhoa), columnIndex);
                }
                sorter.setRowFilter(rf);
            } catch (java.util.regex.PatternSyntaxException e) {
                JOptionPane.showMessageDialog(this, "Lỗi cú pháp biểu thức tìm kiếm.", "Lỗi tìm kiếm", JOptionPane.ERROR_MESSAGE);
                sorter.setRowFilter(null);
            }
        }
        if (tblKhachHang.getRowCount() == 0) {
             JOptionPane.showMessageDialog(this, "Không tìm thấy khách hàng nào phù hợp.", "Kết quả tìm kiếm", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void moFormThemSua(KhachHangDto khDto) {
        boolean isEditMode = (khDto != null);
        String dialogTitle = isEditMode ? "Sửa Thông Tin Khách Hàng" : "Thêm Khách Hàng Mới";

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), dialogTitle, true);
        dialog.setSize(480, 380);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtMaKH = new JTextField(20);
        JTextField txtTenKH = new JTextField(20);
        JTextField txtCMND = new JTextField(20);
        JTextField txtSDT = new JTextField(20);
        JTextField txtDiaChi = new JTextField(20);
        JTextField txtNgayNhan = new JTextField(10);
        JTextField txtNgayTra = new JTextField(10);
        JButton btnLuu = new JButton(isEditMode ? "Cập nhật" : "Thêm");
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");


        if (isEditMode) {
            txtMaKH.setText(khDto.getMaKH());
            txtMaKH.setEditable(false);
            txtTenKH.setText(khDto.getTenKH());
            txtCMND.setText(khDto.getCmnd() != null ? khDto.getCmnd() : "");
            txtSDT.setText(khDto.getSdt() != null ? khDto.getSdt() : "");
            txtDiaChi.setText(khDto.getDiaChi() != null ? khDto.getDiaChi() : "");
            txtNgayNhan.setText(khDto.getNgayNhan() != null ? khDto.getNgayNhan().format(dateFormatter) : "");
            txtNgayTra.setText(khDto.getNgayTra() != null ? khDto.getNgayTra().format(dateFormatter) : "");
        } else {
            txtNgayNhan.setText(LocalDate.now().format(dateFormatter));
        }

        int y = 0;
        gbc.gridx = 0; gbc.gridy = y; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(new JLabel("Mã KH (*):"), gbc);
        gbc.gridx = 1; dialog.add(txtMaKH, gbc);

        y++; gbc.gridx = 0; gbc.gridy = y;
        dialog.add(new JLabel("Tên KH (*):"), gbc);
        gbc.gridx = 1; dialog.add(txtTenKH, gbc);

        y++; gbc.gridx = 0; gbc.gridy = y;
        dialog.add(new JLabel("CMND/CCCD:"), gbc);
        gbc.gridx = 1; dialog.add(txtCMND, gbc);

        y++; gbc.gridx = 0; gbc.gridy = y;
        dialog.add(new JLabel("Số điện thoại:"), gbc);
        gbc.gridx = 1; dialog.add(txtSDT, gbc);

        y++; gbc.gridx = 0; gbc.gridy = y;
        dialog.add(new JLabel("Địa chỉ:"), gbc);
        gbc.gridx = 1; dialog.add(txtDiaChi, gbc);

        y++; gbc.gridx = 0; gbc.gridy = y;
        dialog.add(new JLabel("Ngày Nhận (dd/MM/yyyy):"), gbc);
        gbc.gridx = 1; dialog.add(txtNgayNhan, gbc);

        y++; gbc.gridx = 0; gbc.gridy = y;
        dialog.add(new JLabel("Ngày Trả (dd/MM/yyyy):"), gbc);
        gbc.gridx = 1; dialog.add(txtNgayTra, gbc);

        y++; gbc.gridx = 0; gbc.gridy = y; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        dialog.add(btnLuu, gbc);

        btnLuu.addActionListener(e -> {
            try {
                String maKHValue = txtMaKH.getText().trim();
                String tenKHValue = txtTenKH.getText().trim();
                String cmndValue = txtCMND.getText().trim();
                String sdtValue = txtSDT.getText().trim();
                String diaChiValue = txtDiaChi.getText().trim();
                LocalDate ngayNhanValue = null;
                LocalDate ngayTraValue = null;

                if (maKHValue.isEmpty() || tenKHValue.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Mã KH và Tên KH không được để trống.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (!txtNgayNhan.getText().trim().isEmpty()) {
                    ngayNhanValue = LocalDate.parse(txtNgayNhan.getText().trim(), dateFormatter);
                }
                if (!txtNgayTra.getText().trim().isEmpty()) {
                    ngayTraValue = LocalDate.parse(txtNgayTra.getText().trim(), dateFormatter);
                }
                if (ngayNhanValue != null && ngayTraValue != null && ngayTraValue.isBefore(ngayNhanValue)) {
                    JOptionPane.showMessageDialog(dialog, "Ngày trả không thể trước ngày nhận.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                KhachHangDto newKhDto = new KhachHangDto(maKHValue, tenKHValue, cmndValue, sdtValue, diaChiValue, ngayNhanValue, ngayTraValue);
                boolean success;
                if (isEditMode) {
                    success = khachHangBusinessService.updateKhachHang(newKhDto);
                } else {
                    KhachHangDto existingKh = khachHangBusinessService.getAllKhachHang().stream()
                                                .filter(kh -> kh.getMaKH().equalsIgnoreCase(maKHValue))
                                                .findFirst().orElse(null);
                    if (existingKh != null) {
                        JOptionPane.showMessageDialog(dialog, "Mã khách hàng đã tồn tại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    success = khachHangBusinessService.addKhachHang(newKhDto);
                }

                if (success) {
                    loadKhachHangData();
                    dialog.dispose();
                    JOptionPane.showMessageDialog(this, (isEditMode ? "Cập nhật" : "Thêm") + " khách hàng thành công.");
                } else {
                    JOptionPane.showMessageDialog(dialog, (isEditMode ? "Cập nhật" : "Thêm") + " khách hàng thất bại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (DateTimeParseException ex) {
                 JOptionPane.showMessageDialog(dialog, "Lỗi định dạng ngày (dd/MM/yyyy): " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
            catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog, "Lỗi khi lưu dữ liệu: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void xoaKhachHang() {
        int selectedRow = tblKhachHang.getSelectedRow();
        if (selectedRow >= 0) {
            int modelRow = tblKhachHang.convertRowIndexToModel(selectedRow);
            int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa khách hàng này?", "Xác nhận xóa", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                String maKH = tableModel.getValueAt(modelRow, 0).toString();
                boolean result = khachHangBusinessService.deleteKhachHang(maKH);
                if (result) {
                    loadKhachHangData();
                    JOptionPane.showMessageDialog(this, "Xóa khách hàng thành công.");
                } else {
                    JOptionPane.showMessageDialog(this, "Xóa khách hàng thất bại. Có thể khách hàng đang được tham chiếu trong hóa đơn hoặc các bản ghi khác.");
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn khách hàng để xóa.");
        }
    }
}
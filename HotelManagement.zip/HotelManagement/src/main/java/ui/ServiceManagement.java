package ui;

import businessservice.IDichVuBusinessService;
import dto.DichVuDto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.regex.Pattern;

public class ServiceManagement extends JPanel {
    private IDichVuBusinessService dichVuBusinessService;

    private JTable tblDichVu;
    private DefaultTableModel tableModel;
    private JButton btnThem, btnSua, btnXoa, btnLamMoi, btnTimKiem;
    private JTextField txtTimKiem;
    private JComboBox<String> cmbTieuChiTimKiem;
    private TableRowSorter<DefaultTableModel> sorter;

    public ServiceManagement() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- Panel Tìm kiếm ---
        JPanel topPanel = new JPanel(new BorderLayout(5,5));
        JPanel searchControlsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        cmbTieuChiTimKiem = new JComboBox<>(new String[]{"Theo Tên Dịch Vụ", "Theo Mã DV"});
        searchControlsPanel.add(new JLabel("Tìm kiếm:"));
        searchControlsPanel.add(cmbTieuChiTimKiem);

        txtTimKiem = new JTextField(20);
        searchControlsPanel.add(txtTimKiem);

        btnTimKiem = new JButton("Tìm");
        searchControlsPanel.add(btnTimKiem);

        topPanel.add(searchControlsPanel, BorderLayout.WEST);

        btnLamMoi = new JButton("Làm mới DS");
        JPanel refreshPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        refreshPanel.add(btnLamMoi);
        topPanel.add(refreshPanel, BorderLayout.EAST);

        add(topPanel, BorderLayout.NORTH);


        // --- Bảng hiển thị dịch vụ ---
        String[] columns = {"Mã DV", "Tên dịch vụ", "Đơn giá"};
        tableModel = new DefaultTableModel(columns, 0){
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblDichVu = new JTable(tableModel);
        sorter = new TableRowSorter<>(tableModel);
        tblDichVu.setRowSorter(sorter); 
        add(new JScrollPane(tblDichVu), BorderLayout.CENTER);

        // --- Panel chứa nút chức năng ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        btnThem = new JButton("Thêm Dịch Vụ");
        btnSua = new JButton("Sửa Dịch Vụ");
        btnXoa = new JButton("Xóa Dịch Vụ");
        buttonPanel.add(btnThem);
        buttonPanel.add(btnSua);
        buttonPanel.add(btnXoa);
        add(buttonPanel, BorderLayout.SOUTH);

        // --- Sự kiện nút ---
        btnThem.addActionListener(e -> moFormThemSua(null));
        btnSua.addActionListener(e -> {
            int selectedViewRow = tblDichVu.getSelectedRow();
            if (selectedViewRow >= 0) {
                int modelRow = tblDichVu.convertRowIndexToModel(selectedViewRow);
                String maDV = tableModel.getValueAt(modelRow, 0).toString();
                DichVuDto dvToEdit = dichVuBusinessService.getAllDichVus().stream()
                                    .filter(dv -> dv.getMaDV().equals(maDV))
                                    .findFirst().orElse(null);
                if (dvToEdit != null) {
                    moFormThemSua(dvToEdit);
                } else {
                    JOptionPane.showMessageDialog(this, "Không tìm thấy thông tin dịch vụ để sửa.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Vui lòng chọn dịch vụ để sửa.");
            }
        });
        btnXoa.addActionListener(e -> xoaDichVu());
        btnLamMoi.addActionListener(e -> {
            txtTimKiem.setText("");
            sorter.setRowFilter(null);
            loadDichVuData();
            JOptionPane.showMessageDialog(this, "Danh sách dịch vụ đã được làm mới.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        });
        btnTimKiem.addActionListener(e -> timKiemDichVu());
        txtTimKiem.addActionListener(e -> timKiemDichVu());

        tblDichVu.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tblDichVu.getSelectedRow() != -1) {
                    int selectedViewRow = tblDichVu.getSelectedRow();
                    int modelRow = tblDichVu.convertRowIndexToModel(selectedViewRow);
                    String maDV = tableModel.getValueAt(modelRow, 0).toString();
                    DichVuDto dvToEdit = dichVuBusinessService.getAllDichVus().stream()
                                    .filter(dv -> dv.getMaDV().equals(maDV))
                                    .findFirst().orElse(null);
                    if (dvToEdit != null) {
                        moFormThemSua(dvToEdit);
                    }
                }
            }
        });
    }

    public void setDichVuBusinessService(IDichVuBusinessService service) {
        this.dichVuBusinessService = service;
        if (this.dichVuBusinessService != null) {
            loadDichVuData();
        }
    }

    private void loadDichVuData() {
        if (dichVuBusinessService == null) {
            System.err.println("DichVuBusinessService is null in ServiceManagement.loadDichVuData()");
            return;
        }

        List<DichVuDto> list = dichVuBusinessService.getAllDichVus();
        tableModel.setRowCount(0);
        if (list != null) {
            for (DichVuDto dv : list) {
                tableModel.addRow(new Object[]{
                    dv.getMaDV(),
                    dv.getTenDV(),
                    String.format("%,.0f", dv.getDonGia())
                });
            }
        }
    }

    private void timKiemDichVu() {
        String tuKhoa = txtTimKiem.getText().trim();
        String tieuChi = cmbTieuChiTimKiem.getSelectedItem().toString();

        if (tuKhoa.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            try {
                RowFilter<DefaultTableModel, Object> rf = null;
                int columnIndex = -1;

                if (tieuChi.equals("Theo Tên Dịch Vụ")) {
                    columnIndex = 1; // Cột Tên DV
                } else if (tieuChi.equals("Theo Mã DV")) {
                    columnIndex = 0; // Cột Mã DV
                }

                if (columnIndex != -1) {
                    rf = RowFilter.regexFilter("(?i)" + Pattern.quote(tuKhoa), columnIndex);
                }
                sorter.setRowFilter(rf);
            } catch (java.util.regex.PatternSyntaxException e) {
                 JOptionPane.showMessageDialog(this, "Lỗi cú pháp biểu thức tìm kiếm.", "Lỗi tìm kiếm", JOptionPane.ERROR_MESSAGE);
                sorter.setRowFilter(null);
            }
        }
         if (tblDichVu.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy dịch vụ nào phù hợp.", "Kết quả tìm kiếm", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void moFormThemSua(DichVuDto dvDto) {
        boolean isEditMode = (dvDto != null);
        String dialogTitle = isEditMode ? "Sửa Thông Tin Dịch Vụ" : "Thêm Dịch Vụ Mới";

        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), dialogTitle, true);
        dialog.setSize(430, 250);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField txtMa = new JTextField(20);
        JTextField txtTen = new JTextField(20);
        JTextField txtGia = new JTextField(20);
        JButton btnLuu = new JButton(isEditMode ? "Cập nhật" : "Thêm");

        if (isEditMode) {
            txtMa.setText(dvDto.getMaDV());
            txtMa.setEditable(false);
            txtTen.setText(dvDto.getTenDV());
            txtGia.setText(String.valueOf(dvDto.getDonGia()));
        }

        int yPos = 0;
        gbc.gridx = 0; gbc.gridy = yPos; gbc.anchor = GridBagConstraints.WEST;
        dialog.add(new JLabel("Mã DV (*):"), gbc);
        gbc.gridx = 1; gbc.weightx = 1.0; dialog.add(txtMa, gbc); gbc.weightx = 0;

        yPos++; gbc.gridx = 0; gbc.gridy = yPos;
        dialog.add(new JLabel("Tên dịch vụ (*):"), gbc);
        gbc.gridx = 1; dialog.add(txtTen, gbc);

        yPos++; gbc.gridx = 0; gbc.gridy = yPos;
        dialog.add(new JLabel("Đơn giá (*):"), gbc);
        gbc.gridx = 1; dialog.add(txtGia, gbc);

        yPos++; gbc.gridx = 0; gbc.gridy = yPos; gbc.gridwidth = 2; gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        dialog.add(btnLuu, gbc);

        btnLuu.addActionListener(e -> {
            String ma = txtMa.getText().trim();
            String ten = txtTen.getText().trim();
            String giaStr = txtGia.getText().trim();

            if (ma.isEmpty() || ten.isEmpty() || giaStr.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Vui lòng nhập đầy đủ thông tin (Mã, Tên, Đơn giá).", "Lỗi Nhập Liệu", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                double gia = Double.parseDouble(giaStr);
                if (gia < 0) {
                     JOptionPane.showMessageDialog(dialog, "Đơn giá phải là số không âm.", "Lỗi Nhập Liệu", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                DichVuDto newDvDto = new DichVuDto(ma, ten, gia);
                boolean success;

                if (isEditMode) {
                    success = dichVuBusinessService.updateDichVu(newDvDto);
                } else {
                    DichVuDto existingDV = dichVuBusinessService.getAllDichVus().stream()
                                           .filter(dv -> dv.getMaDV().equalsIgnoreCase(ma))
                                           .findFirst().orElse(null);
                    if (existingDV != null) {
                        JOptionPane.showMessageDialog(dialog, "Mã dịch vụ đã tồn tại!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    success = dichVuBusinessService.addDichVu(newDvDto);
                }

                if (success) {
                    loadDichVuData();
                    dialog.dispose();
                    JOptionPane.showMessageDialog(this, (isEditMode ? "Cập nhật" : "Thêm") + " dịch vụ thành công.");
                } else {
                    JOptionPane.showMessageDialog(dialog, (isEditMode ? "Cập nhật" : "Thêm") + " dịch vụ thất bại.", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Đơn giá phải là một số hợp lệ.", "Lỗi Định Dạng", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                 JOptionPane.showMessageDialog(dialog, "Đã xảy ra lỗi: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
                 ex.printStackTrace();
            }
        });

        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void xoaDichVu() {
        int selectedViewRow = tblDichVu.getSelectedRow();
        if (selectedViewRow >= 0) {
            int modelRow = tblDichVu.convertRowIndexToModel(selectedViewRow);
            String maDV = tableModel.getValueAt(modelRow, 0).toString();
            String tenDV = tableModel.getValueAt(modelRow, 1).toString();


            int confirm = JOptionPane.showConfirmDialog(this,
                    "Bạn có chắc chắn muốn xoá dịch vụ: " + tenDV + " (Mã: " + maDV + ")?\nThao tác này không thể hoàn tác.",
                    "Xác nhận xoá",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                boolean isDeleted = dichVuBusinessService.deleteDichVu(maDV);
                if (isDeleted) {
                    loadDichVuData(); // Tải lại bảng
                    JOptionPane.showMessageDialog(this, "Xoá dịch vụ thành công.");
                } else {
                    JOptionPane.showMessageDialog(this, "Không thể xoá dịch vụ.\nDịch vụ có thể đang được sử dụng trong hóa đơn hoặc các bản ghi khác.", "Lỗi Xóa", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn dịch vụ để xoá.");
        }
    }
}